import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  BrainCircuit, 
  Layers, 
  HelpCircle, 
  ArrowRight, 
  RefreshCw, 
  CheckCircle, 
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Award
} from 'lucide-react';

export default function QuizPage({ initialMode = 'quiz' }) {
  const { notes, activeNote, setActiveNote, submitQuizScore } = useApp();
  const [toolMode, setToolMode] = useState(initialMode);

  useEffect(() => {
    setToolMode(initialMode);
  }, [initialMode]);

  // Quiz State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);

  // Flashcards State
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (notes.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto text-center space-y-6 px-6 py-20 bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
        <div className="w-16 h-16 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-cyan-glow text-white">
          <BrainCircuit size={32} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white font-sans">No Practice Materials</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed font-sans">
            Generate study notes from an uploaded slide deck or PDF first to extract interactive revision flashcards and practice quizzes.
          </p>
        </div>
      </div>
    );
  }

  const currentNote = activeNote || notes[0];
  const mcqs = currentNote.mcqs || [];
  const flashcards = currentNote.flashcards || [];

  // Reset indices on note swap
  useEffect(() => {
    resetQuiz();
    setCurrentCardIndex(0);
    setIsFlipped(false);
  }, [activeNote]);

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedOptionIndex(null);
    setIsAnswerSubmitted(false);
    setQuizScore(0);
    setIsQuizCompleted(false);
  };

  const handleSubmitAnswer = () => {
    if (selectedOptionIndex === null) return;
    setIsAnswerSubmitted(true);
    if (selectedOptionIndex === mcqs[currentQuestionIndex].answerIndex) {
      setQuizScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOptionIndex(null);
    setIsAnswerSubmitted(false);
    if (currentQuestionIndex + 1 < mcqs.length) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setIsQuizCompleted(true);
      submitQuizScore(currentNote._id, quizScore + (selectedOptionIndex === mcqs[currentQuestionIndex].answerIndex ? 1 : 0), mcqs.length);
    }
  };

  const handleFlashcardFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleNextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCardIndex(prev => (prev + 1) % flashcards.length);
    }, 150);
  };

  const handlePrevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCardIndex(prev => (prev - 1 + flashcards.length) % flashcards.length);
    }, 150);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-5xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header with Mode Switches */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200/50 dark:border-white/5">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
            {toolMode === 'quiz' ? <BrainCircuit size={28} className="text-purple-400" /> : <Layers size={28} className="text-pink-400" />}
            <span>{toolMode === 'quiz' ? 'Practice Test Builder' : 'Revision Flashcards'}</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase font-bold tracking-wider">
            Context: {currentNote.title}
          </p>
        </div>

        {/* Option toggles */}
        <div className="inline-flex p-1 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-xl self-start sm:self-auto">
          <button
            onClick={() => setToolMode('quiz')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${toolMode === 'quiz' ? 'bg-purple-500/15 border border-purple-500/30 text-purple-600 dark:text-purple-300' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            <BrainCircuit size={14} />
            <span>Quiz Test</span>
          </button>
          <button
            onClick={() => setToolMode('flashcards')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${toolMode === 'flashcards' ? 'bg-pink-500/15 border border-pink-500/30 text-pink-600 dark:text-pink-300' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            <Layers size={14} />
            <span>Flashcards</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Outline Selector Side list */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Select Study Context</h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {notes.map(n => (
              <button
                key={n._id}
                onClick={() => setActiveNote(n)}
                className={`
                  w-full p-4 rounded-xl text-left text-xs transition-all flex items-start gap-3 border
                  ${currentNote._id === n._id 
                    ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-600 dark:text-cyan-300 font-semibold' 
                    : 'bg-white dark:bg-white/5 border-slate-200/60 dark:border-white/5 text-slate-700 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10'
                  }
                `}
              >
                <div className="overflow-hidden flex-1">
                  <p className="font-semibold truncate">{n.title}</p>
                  <span className="inline-block mt-1 text-[9px] uppercase font-bold tracking-widest text-slate-400">{n.subject}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Content Box */}
        <div className="lg:col-span-3">
          
          {/* QUIZ INTERFACE */}
          {toolMode === 'quiz' && (
            <div className="p-6 sm:p-8 rounded-2xl glass-panel min-h-[350px] flex flex-col justify-between">
              {mcqs.length === 0 ? (
                <div className="text-center py-12 space-y-2">
                  <AlertCircle className="mx-auto text-slate-400" size={32} />
                  <p className="text-xs text-slate-400 italic">No multiple-choice questions found in this study guide.</p>
                </div>
              ) : isQuizCompleted ? (
                <div className="text-center py-10 space-y-6 max-w-sm mx-auto">
                  <div className="w-16 h-16 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-2xl flex items-center justify-center text-white mx-auto shadow-cyan-glow">
                    <Award size={32} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold">Quiz Completed!</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      You scored <strong className="text-cyan-500">{quizScore}</strong> out of <strong className="text-slate-800 dark:text-slate-200">{mcqs.length}</strong> questions correct.
                    </p>
                  </div>
                  <button
                    onClick={resetQuiz}
                    className="w-full py-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 hover:border-cyan-400/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw size={14} />
                    <span>Try Quiz Again</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Progress Header */}
                  <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                    <span>Question {currentQuestionIndex + 1} of {mcqs.length}</span>
                    <span className="text-cyan-500">Score: {quizScore}</span>
                  </div>

                  {/* Question */}
                  <h3 className="text-sm font-bold text-slate-800 dark:text-white leading-relaxed">
                    {mcqs[currentQuestionIndex].question}
                  </h3>

                  {/* Options */}
                  <div className="grid grid-cols-1 gap-3">
                    {mcqs[currentQuestionIndex].options.map((opt, oIdx) => {
                      let btnStyle = "border-slate-200 dark:border-white/5 bg-white dark:bg-white/5 text-slate-700 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-white/10";
                      
                      if (isAnswerSubmitted) {
                        if (oIdx === mcqs[currentQuestionIndex].answerIndex) {
                          btnStyle = "border-green-500/40 bg-green-500/10 text-green-600 dark:text-green-300 font-semibold";
                        } else if (selectedOptionIndex === oIdx) {
                          btnStyle = "border-red-500/40 bg-red-500/10 text-red-600 dark:text-red-300 font-semibold";
                        } else {
                          btnStyle = "border-slate-200 dark:border-white/5 bg-white dark:bg-white/5 text-slate-400 opacity-60";
                        }
                      } else if (selectedOptionIndex === oIdx) {
                        btnStyle = "border-cyan-500/50 bg-cyan-500/10 text-cyan-600 dark:text-cyan-300 font-semibold";
                      }

                      return (
                        <button
                          key={oIdx}
                          type="button"
                          disabled={isAnswerSubmitted}
                          onClick={() => setSelectedOptionIndex(oIdx)}
                          className={`w-full p-4 rounded-xl text-left text-xs transition-all border flex items-center justify-between ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {isAnswerSubmitted && oIdx === mcqs[currentQuestionIndex].answerIndex && <CheckCircle size={14} className="text-green-500 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation feedback */}
                  {isAnswerSubmitted && mcqs[currentQuestionIndex].explanation && (
                    <div className="p-4 rounded-xl bg-cyan-500/5 dark:bg-cyan-500/10 border border-cyan-400/20 text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      <strong>Rationale:</strong> {mcqs[currentQuestionIndex].explanation}
                    </div>
                  )}

                  {/* Nav Footer */}
                  <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-white/5">
                    {!isAnswerSubmitted ? (
                      <button
                        onClick={handleSubmitAnswer}
                        disabled={selectedOptionIndex === null}
                        className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold hover:opacity-90 disabled:opacity-50 transition-all flex items-center gap-1.5"
                      >
                        <span>Submit Answer</span>
                        <CheckCircle size={14} />
                      </button>
                    ) : (
                      <button
                        onClick={handleNextQuestion}
                        className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold hover:opacity-90 transition-all flex items-center gap-1.5"
                      >
                        <span>{currentQuestionIndex + 1 === mcqs.length ? 'Finish Quiz' : 'Next Question'}</span>
                        <ArrowRight size={14} />
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* FLASHCARDS INTERFACE */}
          {toolMode === 'flashcards' && (
            <div className="space-y-6">
              {flashcards.length === 0 ? (
                <div className="p-8 rounded-2xl glass-panel text-center text-xs text-slate-400 italic">
                  <AlertCircle className="mx-auto mb-2 text-slate-400" size={32} />
                  No revision flashcards compiled.
                </div>
              ) : (
                <div className="space-y-8">
                  {/* Progress Indicators */}
                  <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                    <span>Card {currentCardIndex + 1} of {flashcards.length}</span>
                    <span>Click card to reveal definition</span>
                  </div>

                  {/* Flippable Card container */}
                  <div 
                    onClick={handleFlashcardFlip}
                    className="w-full min-h-[220px] bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:border-cyan-400/30 shadow-lg relative overflow-hidden select-none"
                  >
                    <div className="absolute top-3 right-3 text-[9px] uppercase tracking-wider text-slate-400 font-bold px-2 py-0.5 bg-slate-100 dark:bg-white/5 rounded">
                      {isFlipped ? 'Answer definition' : 'Revision query'}
                    </div>

                    {isFlipped ? (
                      <div className="space-y-3">
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Definition Answer</p>
                        <p className="text-sm font-bold text-cyan-500 leading-relaxed font-sans">{flashcards[currentCardIndex].answer}</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Concept Query</p>
                        <p className="text-sm font-bold text-slate-800 dark:text-white leading-relaxed font-sans">{flashcards[currentCardIndex].question}</p>
                      </div>
                    )}
                  </div>

                  {/* Card Navigations */}
                  <div className="flex items-center justify-center gap-4">
                    <button
                      onClick={handlePrevCard}
                      className="p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 hover:border-cyan-400/30 text-slate-600 dark:text-slate-300 rounded-xl transition-all"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{currentCardIndex + 1} / {flashcards.length}</span>
                    <button
                      onClick={handleNextCard}
                      className="p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 hover:border-cyan-400/30 text-slate-600 dark:text-slate-300 rounded-xl transition-all"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
