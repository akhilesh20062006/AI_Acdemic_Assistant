import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  Settings, 
  Sun, 
  Moon, 
  Key, 
  Database, 
  RotateCcw, 
  Bell, 
  ShieldCheck, 
  Save,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function SettingsPage() {
  const { theme, setTheme, logout } = useApp();
  
  // Custom API key local states
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('GEMINI_API_KEY') || '');
  const [saveKeySuccess, setSaveKeySuccess] = useState(false);
  
  // Notification states
  const [notifyDaily, setNotifyDaily] = useState(true);
  const [notifyQuiz, setNotifyQuiz] = useState(true);
  const [notifyGoals, setNotifyGoals] = useState(false);

  const handleSaveApiKey = (e) => {
    e.preventDefault();
    localStorage.setItem('GEMINI_API_KEY', apiKey.trim());
    setSaveKeySuccess(true);
    confetti({ particleCount: 30, spread: 40 });
    setTimeout(() => setSaveKeySuccess(false), 3000);
  };

  const handleClearApiKey = () => {
    localStorage.removeItem('GEMINI_API_KEY');
    setApiKey('');
    alert('Gemini API key removed from local browser memory.');
  };

  const handleResetApp = () => {
    if (confirm('🚨 Warning: This will delete all locally cached settings and logout your session. Do you wish to proceed?')) {
      localStorage.clear();
      logout();
      window.location.reload();
    }
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-4xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
          <Settings size={28} className="text-cyan-400" />
          <span>System Settings</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Configure preferences, API integrations, and database operations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
        
        {/* Left Side: Theme & API settings (Span 2) */}
        <div className="md:col-span-2 space-y-6">
          
          {/* Card 1: Custom API keys */}
          <div className="p-6 rounded-2xl glass-panel space-y-6">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2 border-b border-slate-200/50 dark:border-white/5 pb-3">
              <Key size={16} className="text-cyan-400" />
              <span>Personal Gemini API Key</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
              By default, the platform uses our backend API process configuration. Add your own Google Gemini API Key to run queries directly from your browser client using your own quotas.
            </p>
            <form onSubmit={handleSaveApiKey} className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Gemini API Key</label>
                <input 
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full p-3 rounded-xl glass-input text-xs font-mono"
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleClearApiKey}
                  className="text-xs text-slate-400 hover:text-red-400 transition-colors underline"
                >
                  Clear Key
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-xl text-white text-xs font-bold shadow-cyan-glow flex items-center gap-1 hover:opacity-95"
                >
                  {saveKeySuccess ? <CheckCircle2 size={14} /> : <Save size={14} />}
                  <span>{saveKeySuccess ? 'Saved Key!' : 'Save Credentials'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Card 2: Appearance & Preferences */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2 border-b border-slate-200/50 dark:border-white/5 pb-3">
              <Sun size={16} className="text-purple-400" />
              <span>Visual Appearance</span>
            </h3>
            <div className="flex items-center justify-between text-xs">
              <div>
                <p className="font-semibold text-slate-800 dark:text-slate-200">Active Color Theme</p>
                <p className="text-[10px] text-slate-400 mt-1">Switch between dark mode glow and light mode contrast.</p>
              </div>
              
              {/* Toggle switch */}
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="px-4 py-2 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 hover:border-cyan-400/20 text-slate-700 dark:text-slate-300 hover:text-slate-800 dark:hover:text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
              >
                {theme === 'dark' ? (
                  <>
                    <Moon size={14} className="text-purple-400 animate-spin-slow" />
                    <span>Dark Glow</span>
                  </>
                ) : (
                  <>
                    <Sun size={14} className="text-yellow-400 animate-spin-slow" />
                    <span>Light Mode</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Card 3: Notification Toggles */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2 border-b border-slate-200/50 dark:border-white/5 pb-3">
              <Bell size={16} className="text-pink-400" />
              <span>System Reminders</span>
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 block">Daily Streak Reminders</span>
                  <span className="text-[9px] text-slate-500">Alert me if my daily study streak is close to resetting.</span>
                </div>
                <input 
                  type="checkbox" checked={notifyDaily} onChange={e => setNotifyDaily(e.target.checked)}
                  className="rounded bg-slate-900 border-white/10 text-cyan-500 focus:ring-0"
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 block">Quiz Performance Summaries</span>
                  <span className="text-[9px] text-slate-500">Log score badges to browser storage immediately.</span>
                </div>
                <input 
                  type="checkbox" checked={notifyQuiz} onChange={e => setNotifyQuiz(e.target.checked)}
                  className="rounded bg-slate-900 border-white/10 text-cyan-500 focus:ring-0"
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 block">Pomodoro Completion Sound</span>
                  <span className="text-[9px] text-slate-500">Play synthesis frequency beep when break ends.</span>
                </div>
                <input 
                  type="checkbox" checked={notifyGoals} onChange={e => setNotifyGoals(e.target.checked)}
                  className="rounded bg-slate-900 border-white/10 text-cyan-500 focus:ring-0"
                />
              </div>
            </div>
          </div>

        </div>

        {/* Right Side: Database statuses & hard reset (Span 1) */}
        <div className="space-y-6">
          
          {/* Database management and switches */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-3">
              <Database size={16} className="text-cyan-400" />
              <span>Database Status</span>
            </h3>
            
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-white dark:bg-white/5 rounded-xl border border-slate-200/50 dark:border-white/5 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Backend Server:</span>
                  <span className="font-bold px-2 py-0.5 rounded bg-green-500/20 text-green-300">
                    ONLINE
                  </span>
                </div>
                <p className="text-[9px] text-slate-500 mt-1">StudySync Portal is running on direct API routes.</p>
              </div>
            </div>
          </div>

          {/* Hard reset toolcard */}
          <div className="p-6 rounded-2xl glass-panel border border-red-500/20 space-y-4">
            <h3 className="text-sm font-bold text-red-400 flex items-center gap-2 border-b border-red-500/10 pb-3">
              <RotateCcw size={16} className="text-red-400" />
              <span>Developer Options</span>
            </h3>
            <p className="text-xs text-slate-450 dark:text-slate-400 leading-relaxed">
              Run a system reset to clear local settings.
            </p>
            <button
              onClick={handleResetApp}
              className="w-full py-2.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 hover:text-white rounded-xl text-xs font-bold transition-all text-center"
            >
              Reset Cache & Logout
            </button>
          </div>

          {/* Verification badges */}
          <div className="p-4 bg-cyan-950/20 border border-cyan-500/10 rounded-2xl flex items-center gap-2 text-[10px] text-cyan-300 font-bold justify-center">
            <ShieldCheck size={14} className="shrink-0" />
            <span>Secure Client Sandbox</span>
          </div>

        </div>

      </div>

    </div>
  );
}
