import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';

const AppContext = createContext();

export const useApp = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const [isBackendLive, setIsBackendLive] = useState(false);
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [user, setUser] = useState(null);
  const [uploads, setUploads] = useState([]);
  const [notes, setNotes] = useState([]);
  const [activeNote, setActiveNote] = useState(null);
  const [activeUpload, setActiveUpload] = useState(null);
  const [chatHistory, setChatHistory] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [loading, setLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  // Apply theme class
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Ping backend to check if live
  useEffect(() => {
    const checkBackend = async () => {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          setIsBackendLive(true);
          console.log('Express API Server detected. Operating in Live Full-Stack Mode.');
        } else {
          throw new Error('Backend health check non-ok');
        }
      } catch (e) {
        setIsBackendLive(false);
        console.warn('Backend server is offline or unreachable. StudySync requires a live server.');
      }
    };
    checkBackend();
    
    // Periodically poll backend availability
    const timer = setInterval(checkBackend, 10000);
    return () => clearInterval(timer);
  }, []);

  // Hydrate data when backend becomes live and token is available
  useEffect(() => {
    if (isBackendLive && token) {
      fetchDashboardData();
    }
  }, [isBackendLive, token]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const headers = { 'Authorization': `Bearer ${token}` };

      // Load Profile
      const profileRes = await fetch('/api/auth/profile', { headers });
      if (profileRes.status === 401) {
        logout();
        return;
      }
      if (profileRes.ok) {
        const profile = await profileRes.json();
        setUser(profile);
      }

      // Load Uploads
      const uploadsRes = await fetch('/api/uploads', { headers });
      if (uploadsRes.ok) {
        const upList = await uploadsRes.json();
        setUploads(upList);
        if (upList.length > 0 && !activeUpload) {
          setActiveUpload(upList[0]);
        }
      }

      // Load Notes
      const notesRes = await fetch('/api/notes', { headers });
      if (notesRes.ok) {
        const noteList = await notesRes.json();
        setNotes(noteList);
        if (noteList.length > 0 && !activeNote) {
          setActiveNote(noteList[0]);
        }
      }

      // Load Tasks
      const tasksRes = await fetch('/api/study/tasks', { headers });
      if (tasksRes.ok) {
        setTasks(await tasksRes.json());
      }
    } catch (e) {
      console.error('Failed to load dashboard data from Express API:', e);
    } finally {
      setLoading(false);
    }
  };

  // ==========================================
  // AUTHENTICATION OPERATIONS
  // ==========================================
  const login = async (email, password) => {
    setAuthError('');
    try {
      setLoading(true);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (res.ok) {
        setToken(data.token);
        localStorage.setItem('token', data.token);
        setUser(data.user);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        return true;
      } else {
        setAuthError(data.error || 'Login failed.');
        return false;
      }
    } catch (err) {
      setAuthError('Connection refused to backend.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (name, email, password, college, department, year) => {
    setAuthError('');
    try {
      setLoading(true);
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, college, department, year })
      });
      const data = await res.json();
      if (res.ok) {
        setToken(data.token);
        localStorage.setItem('token', data.token);
        setUser(data.user);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        return true;
      } else {
        setAuthError(data.error || 'Registration failed.');
        return false;
      }
    } catch (err) {
      setAuthError('Connection error.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const forgotPassword = async (email) => {
    setAuthError('');
    try {
      setLoading(true);
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (res.ok) {
        return { success: true, token: data.token, message: data.message };
      } else {
        setAuthError(data.error || 'Failed to request reset token.');
        return { success: false, error: data.error };
      }
    } catch (err) {
      setAuthError('Connection error.');
      return { success: false, error: 'Connection error.' };
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email, tokenVal, newPassword) => {
    setAuthError('');
    try {
      setLoading(true);
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, token: tokenVal, newPassword })
      });
      const data = await res.json();
      if (res.ok) {
        return { success: true, message: data.message };
      } else {
        setAuthError(data.error || 'Failed to reset password.');
        return { success: false, error: data.error };
      }
    } catch (err) {
      setAuthError('Connection error.');
      return { success: false, error: 'Connection error.' };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setToken('');
    setUser(null);
    setActiveNote(null);
    setActiveUpload(null);
    setChatHistory([]);
    setUploads([]);
    setNotes([]);
    setTasks([]);
    localStorage.removeItem('token');
  };

  const updateProfile = async (updateData) => {
    if (!user) return;
    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updateData)
      });
      if (res.ok) {
        setUser(await res.json());
      }
    } catch (e) {
      console.error(e);
    }
  };

  // ==========================================
  // UPLOADS OPERATIONS
  // ==========================================
  const uploadFile = async (file, subject = 'General') => {
    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('file', file);
      formData.append('subject', subject);

      const res = await fetch('/api/uploads', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'x-gemini-api-key': localStorage.getItem('GEMINI_API_KEY') || ''
        },
        body: formData
      });
      if (res.ok) {
        const item = await res.json();
        const updatedList = [item, ...uploads];
        setUploads(updatedList);
        if (!activeUpload) setActiveUpload(item);
        return item;
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(`Upload failed: ${errData.error || res.statusText}`);
      }
    } catch (e) {
      console.error('File upload error:', e);
      alert('File upload failed due to a connection failure.');
    } finally {
      setLoading(false);
    }
  };

  const deleteUpload = async (id) => {
    const updatedList = uploads.filter(up => up._id !== id);
    try {
      const res = await fetch(`/api/uploads/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setUploads(updatedList);
        if (activeUpload?._id === id) setActiveUpload(updatedList[0] || null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // ==========================================
  // NOTE GENERATOR OPERATIONS
  // ==========================================
  const generateNote = async (uploadId, mode = 'detailed') => {
    try {
      setLoading(true);
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-gemini-api-key': localStorage.getItem('GEMINI_API_KEY') || ''
        },
        body: JSON.stringify({ uploadId, mode })
      });
      if (res.ok) {
        const item = await res.json();
        const updatedList = [item, ...notes];
        setNotes(updatedList);
        setActiveNote(item);
        confetti({ particleCount: 80, spread: 60 });
        return item;
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(`Failed to generate study guide: ${errData.error || res.statusText}`);
      }
    } catch (e) {
      console.error('Note generation error:', e);
      alert('Failed to generate study guide due to a connection failure.');
    } finally {
      setLoading(false);
    }
  };

  const deleteNote = async (id) => {
    const updatedList = notes.filter(n => n._id !== id);
    try {
      const res = await fetch(`/api/notes/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setNotes(updatedList);
        if (activeNote?._id === id) setActiveNote(updatedList[0] || null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // ==========================================
  // AI CHATBOT OPERATIONS
  // ==========================================
  const sendMessage = async (uploadId, message) => {
    const userMsg = { _id: Math.random().toString(), sender: 'student', text: message, timestamp: new Date().toISOString() };
    setChatHistory(prev => [...prev, userMsg]);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-gemini-api-key': localStorage.getItem('GEMINI_API_KEY') || ''
        },
        body: JSON.stringify({ uploadId, message, history: chatHistory })
      });
      if (res.ok) {
        const data = await res.json();
        const aiMsg = {
          _id: Math.random().toString(),
          sender: 'ai',
          text: data.aiResponse,
          timestamp: new Date().toISOString()
        };
        setChatHistory(prev => [...prev, aiMsg]);
      } else {
        const errData = await res.json().catch(() => ({}));
        const errText = errData.error || `HTTP error! Status: ${res.status}`;
        const errMsg = {
          _id: Math.random().toString(),
          sender: 'ai',
          text: `⚠️ Gemini API Error: ${errText}`,
          timestamp: new Date().toISOString()
        };
        setChatHistory(prev => [...prev, errMsg]);
      }
    } catch (e) {
      console.error('Chat error:', e);
      const errMsg = {
        _id: Math.random().toString(),
        sender: 'ai',
        text: `⚠️ Connection Failure: Cannot reach Express API server at /api/chat.`,
        timestamp: new Date().toISOString()
      };
      setChatHistory(prev => [...prev, errMsg]);
    }
  };

  const loadChatHistory = async (uploadId) => {
    try {
      const res = await fetch(`/api/ai/chat/history?uploadId=${uploadId || ''}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const rawHistory = await res.json();
        const formatted = [];
        rawHistory.forEach(ch => {
          formatted.push({ _id: ch._id + '-s', sender: 'student', text: ch.message, timestamp: ch.timestamp });
          formatted.push({ _id: ch._id + '-a', sender: 'ai', text: ch.aiResponse, timestamp: ch.timestamp });
        });
        setChatHistory(formatted);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // ==========================================
  // STUDY TOOLS OPERATIONS
  // ==========================================
  const createTask = async (title, subject) => {
    const date = new Date().toISOString().split('T')[0];
    try {
      const res = await fetch('/api/study/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title, subject, date })
      });
      if (res.ok) {
        const item = await res.json();
        setTasks([item, ...tasks]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const updateTask = async (id, completed) => {
    const updatedList = tasks.map(t => t._id === id ? { ...t, completed } : t);
    try {
      const res = await fetch(`/api/study/tasks/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ completed })
      });
      if (res.ok) {
        setTasks(updatedList);
        fetchDashboardData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const deleteTask = async (id) => {
    const updatedList = tasks.filter(t => t._id !== id);
    try {
      const res = await fetch(`/api/study/tasks/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setTasks(updatedList);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const submitQuizScore = async (noteId, score, total) => {
    if (!user) return;
    try {
      const res = await fetch('/api/study/score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ quizId: noteId, score, total })
      });
      if (res.ok) {
        const stats = await res.json();
        setUser(prev => ({ ...prev, studyStats: stats }));
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const logStudyTime = async (hours) => {
    if (!user) return;
    try {
      const res = await fetch('/api/study/time', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ hours })
      });
      if (res.ok) {
        const stats = await res.json();
        setUser(prev => ({ ...prev, studyStats: stats }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const incrementStreak = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/study/streak/update', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(prev => ({
          ...prev,
          studyStats: {
            ...prev.studyStats,
            streak: data.streak,
            lastActive: new Date().toISOString()
          }
        }));
        confetti({ particleCount: 60, spread: 50 });
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <AppContext.Provider
      value={{
        isBackendLive,
        token,
        user,
        uploads,
        notes,
        activeNote,
        activeUpload,
        chatHistory,
        tasks,
        theme,
        loading,
        authError,
        setTheme,
        setActiveNote,
        setActiveUpload,
        login,
        register,
        logout,
        forgotPassword,
        resetPassword,
        updateProfile,
        uploadFile,
        deleteUpload,
        generateNote,
        deleteNote,
        sendMessage,
        loadChatHistory,
        createTask,
        updateTask,
        deleteTask,
        submitQuizScore,
        logStudyTime,
        incrementStreak
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
