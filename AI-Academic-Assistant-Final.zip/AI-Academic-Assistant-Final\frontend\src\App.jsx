import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.jsx';
import LandingPage from './pages/LandingPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';
import UploadPage from './pages/UploadPage.jsx';
import NotesPage from './pages/NotesPage.jsx';
import ChatPage from './pages/ChatPage.jsx';
import QuizPage from './pages/QuizPage.jsx';
import StudyToolsPage from './pages/StudyToolsPage.jsx';
import ProfilePage from './pages/ProfilePage.jsx';
import AuthPage from './pages/AuthPage.jsx';
import SettingsPage from './pages/SettingsPage.jsx';
import ContactPage from './pages/ContactPage.jsx';

import { 
  LayoutDashboard, 
  UploadCloud, 
  FileText, 
  MessageSquare, 
  BrainCircuit, 
  CalendarRange, 
  UserCircle2, 
  Sun, 
  Moon, 
  LogOut, 
  GraduationCap,
  Menu,
  X,
  Sparkles,
  Settings,
  Mail,
  Layers,
  ShieldAlert
} from 'lucide-react';

function AppContent() {
  const { user, theme, setTheme, logout, loading, isBackendLive } = useApp();
  const [currentPage, setCurrentPage] = useState('landing');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  // Redirection for active users
  React.useEffect(() => {
    if (user && (currentPage === 'landing' || currentPage === 'auth')) {
      setCurrentPage('dashboard');
    }
  }, [user, currentPage]);

  const triggerAuthPage = (signUp = false) => {
    setIsSignUp(signUp);
    setCurrentPage('auth');
  };

  const handleLogout = () => {
    logout();
    setCurrentPage('landing');
  };

  // If backend is down, block UI with offline state
  if (!isBackendLive) {
    return (
      <div className="min-h-screen bg-[#070415] flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center text-red-500 shadow-lg animate-pulse">
          <ShieldAlert size={32} />
        </div>
        <h1 className="text-2xl font-bold text-white font-sans">StudySync Server Offline</h1>
        <p className="text-slate-400 max-w-md text-xs leading-relaxed font-sans">
          The backend Express API server could not be reached. Please check that your server is running on <code className="text-cyan-400 font-mono">http://localhost:5000</code> by running <code className="text-cyan-400 font-mono">npm run start:backend</code> in your project directory.
        </p>
        <button 
          onClick={() => window.location.reload()}
          className="px-5 py-2 bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-lg text-xs font-semibold text-white shadow-cyan-glow transition-all"
        >
          Check Connection
        </button>
      </div>
    );
  }

  const renderActivePage = () => {
    if (!user && currentPage !== 'landing' && currentPage !== 'auth' && currentPage !== 'contact') {
      return <LandingPage triggerAuth={triggerAuthPage} navigate={setCurrentPage} />;
    }

    switch(currentPage) {
      case 'landing':
        return <LandingPage triggerAuth={triggerAuthPage} navigate={setCurrentPage} />;
      case 'auth':
        return <AuthPage navigate={setCurrentPage} initialSignUp={isSignUp} />;
      case 'dashboard':
        return <DashboardPage navigate={setCurrentPage} />;
      case 'upload':
        return <UploadPage navigate={setCurrentPage} />;
      case 'chat':
        return <ChatPage navigate={setCurrentPage} />;
      case 'short-notes':
        return <NotesPage navigate={setCurrentPage} initialTab="notes" />;
      case 'quiz':
        return <QuizPage navigate={setCurrentPage} initialMode="quiz" />;
      case 'flashcards':
        return <QuizPage navigate={setCurrentPage} initialMode="flashcards" />;
      case 'study-planner':
        return <StudyToolsPage navigate={setCurrentPage} />;
      case 'profile':
        return <ProfilePage navigate={setCurrentPage} />;
      case 'settings':
        return <SettingsPage navigate={setCurrentPage} />;
      case 'contact':
        return <ContactPage navigate={setCurrentPage} />;
      default:
        return <DashboardPage navigate={setCurrentPage} />;
    }
  };

  const navLinks = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'upload', label: 'Upload Notes', icon: UploadCloud },
    { id: 'chat', label: 'AI Chat', icon: MessageSquare },
    { id: 'short-notes', label: 'Short Notes', icon: FileText },
    { id: 'quiz', label: 'Quiz Generator', icon: BrainCircuit },
    { id: 'flashcards', label: 'Flashcards', icon: Layers },
    { id: 'study-planner', label: 'Study Planner', icon: CalendarRange },
    { id: 'profile', label: 'Profile', icon: UserCircle2 },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'contact', label: 'Contact Page', icon: Mail },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row relative overflow-x-hidden">
      
      {/* Background radial overlays */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-glow-purple opacity-40 dark:opacity-60 rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-glow-cyan opacity-30 dark:opacity-40 rounded-full"></div>
      </div>

      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center">
          <div className="w-16 h-16 border-4 border-cyan-400 border-t-purple-600 rounded-full animate-spin mb-4 shadow-cyan-glow"></div>
          <p className="text-white font-semibold text-lg animate-pulse">AI is compiling resources...</p>
        </div>
      )}

      {/* Sidebar Navigation */}
      {user && (
        <>
          {/* Mobile Top Navbar */}
          <div className="md:hidden w-full p-4 bg-white dark:bg-[#0c0920]/90 border-b border-slate-200/80 dark:border-white/5 flex items-center justify-between z-40">
            <div className="flex items-center space-x-2">
              <GraduationCap className="text-cyan-500" size={28} />
              <span className="font-bold text-lg tracking-wide bg-gradient-to-r from-cyan-500 to-purple-500 bg-clip-text text-transparent">StudySync AI</span>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2 rounded-lg bg-slate-50 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 text-slate-600 dark:text-slate-300"
              >
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <button 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 rounded-lg bg-slate-50 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 text-slate-600 dark:text-slate-300"
              >
                {isSidebarOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>

          {/* Actual Sidebar Container */}
          <aside className={`
            fixed md:relative inset-y-0 left-0 w-64 bg-white dark:bg-[#0c0920]/90 border-r border-slate-200/80 dark:border-white/5 flex flex-col z-[100] md:z-10
            transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0
            transition-transform duration-300 ease-in-out py-6 px-4 shrink-0
          `}>
            {/* Desktop Brand logo */}
            <div className="hidden md:flex items-center space-x-3 mb-8 px-2">
              <div className="p-2 bg-gradient-to-tr from-cyan-500 to-purple-600 rounded-xl shadow-cyan-glow">
                <GraduationCap className="text-white" size={24} />
              </div>
              <div>
                <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-cyan-500 to-purple-550 bg-clip-text text-transparent">StudySync AI</span>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-widest uppercase">Academic Assistant</p>
              </div>
            </div>

            {/* Student quick profile card */}
            <div className="p-3 bg-slate-50 dark:bg-purple-950/20 border border-slate-200/50 dark:border-white/5 rounded-xl flex items-center space-x-3 mb-6">
              <img src={user.profileImage} alt={user.name} className="w-10 h-10 rounded-full border border-cyan-500/30" />
              <div className="overflow-hidden">
                <p className="text-xs font-semibold truncate text-slate-800 dark:text-slate-200">{user.name}</p>
                <div className="flex items-center text-[10px] text-cyan-500 dark:text-cyan-400 font-bold space-x-1 mt-0.5">
                  <Sparkles size={10} />
                  <span>Streak: {user.studyStats?.streak || 1} Days</span>
                </div>
              </div>
            </div>

            {/* Nav list */}
            <nav className="flex-1 space-y-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = currentPage === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => {
                      setCurrentPage(link.id);
                      setIsSidebarOpen(false);
                    }}
                    className={`
                      w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-150
                      ${isActive 
                        ? 'bg-cyan-50 dark:bg-cyan-500/10 border-l-4 border-cyan-500 text-cyan-600 dark:text-cyan-300 font-semibold' 
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-white/5'
                      }
                    `}
                  >
                    <Icon size={18} className={isActive ? 'text-cyan-500' : 'text-slate-400 dark:text-slate-500'} />
                    <span>{link.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Sidebar Footer options */}
            <div className="pt-4 border-t border-slate-200/80 dark:border-white/5 space-y-1">
              <div className="px-4 py-2 flex items-center justify-between text-xs text-slate-500">
                <span>Database:</span>
                <span className="font-bold px-2 py-0.5 rounded bg-green-500/10 text-green-600 dark:bg-green-500/20 dark:text-green-300">
                  Live Server
                </span>
              </div>
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="w-full flex items-center space-x-3 px-4 py-2.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-white/5 transition-all"
              >
                {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
                <span>{theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}</span>
              </button>
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-4 py-2.5 rounded-xl text-xs font-medium text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
              >
                <LogOut size={16} />
                <span>Logout Session</span>
              </button>
            </div>
          </aside>
        </>
      )}

      {/* Main Content Area */}
      <main className="flex-1 w-full relative z-10 flex flex-col min-h-screen">
        {user && (
          <header className="hidden md:flex w-full px-8 py-4 bg-white dark:bg-[#0c0920]/90 border-b border-slate-200/80 dark:border-white/5 items-center justify-between z-30 shrink-0">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">
                Portal / {currentPage.replace('-', ' ')}
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-bold uppercase tracking-wider">
                <Sparkles size={14} className="text-cyan-500" />
                <span>Focus Hours: <b className="text-cyan-600 dark:text-cyan-300 font-mono">{user.studyStats?.studyHours?.toFixed(1) || '0.0'} hrs</b></span>
              </div>
              <span className="h-4 w-[1px] bg-slate-200 dark:bg-white/10"></span>
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 text-slate-600 dark:text-slate-300 transition-colors"
                title="Toggle Theme"
              >
                {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
              </button>
              <span className="h-4 w-[1px] bg-slate-200 dark:bg-white/10"></span>
              <div className="flex items-center space-x-2">
                <img src={user.profileImage} alt={user.name} className="w-7 h-7 rounded-full border border-cyan-500/30" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{user.name}</span>
              </div>
            </div>
          </header>
        )}
        <div className="flex-1 w-full overflow-y-auto">
          {renderActivePage()}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
