import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  UploadCloud, 
  FileText, 
  Trash2, 
  MessageSquare, 
  BrainCircuit, 
  CheckCircle,
  FileCheck,
  FolderOpen
} from 'lucide-react';

const SUBJECTS = [
  "Computer Science",
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "History",
  "Literature",
  "General"
];

export default function UploadPage({ navigate }) {
  const { uploads, uploadFile, deleteUpload, generateNote, setActiveUpload, setActiveNote } = useApp();
  
  const [file, setFile] = useState(null);
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [dragActive, setDragActive] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;

    const uploadedItem = await uploadFile(file, subject);
    if (uploadedItem) {
      setUploadSuccess(true);
      setFile(null);
      setTimeout(() => setUploadSuccess(false), 3000);
    }
  };

  const handleGenerateOutline = async (uploadId) => {
    const note = await generateNote(uploadId, 'detailed');
    if (note) {
      setActiveNote(note);
      navigate('short-notes');
    }
  };

  const handleStartChat = (upRecord) => {
    setActiveUpload(upRecord);
    navigate('chat');
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-5xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
          <UploadCloud size={28} className="text-cyan-400" />
          <span>Upload Study Materials</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Upload slides presentations, notes PDFs, or handwritten notebooks snapshots for AI generation.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Side: Upload Form (Span 2) */}
        <div className="md:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl glass-panel space-y-6">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2 border-b border-slate-200/50 dark:border-white/5 pb-3">
              <FolderOpen size={16} className="text-cyan-400" />
              <span>Document File Dropzone</span>
            </h3>

            {uploadSuccess && (
              <div className="p-3.5 bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle size={16} className="text-green-500 shrink-0" />
                <span>Study guide uploaded and processed successfully!</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Drag and Drop Zone */}
              <div 
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                className={`
                  w-full border-2 border-dashed rounded-2xl p-8 text-center flex flex-col items-center justify-center space-y-3 cursor-pointer transition-all
                  ${dragActive 
                    ? 'border-cyan-400 bg-cyan-500/5 dark:bg-cyan-500/10' 
                    : 'border-slate-200 hover:border-slate-300 dark:border-white/10 dark:hover:border-white/20'
                  }
                `}
                onClick={() => document.getElementById('file-upload').click()}
              >
                <input 
                  type="file" 
                  id="file-upload" 
                  className="hidden" 
                  onChange={handleFileChange}
                  accept=".pdf,.txt,.jpeg,.png,.jpg,.doc,.docx"
                />
                
                <div className="p-4 bg-slate-100 dark:bg-white/5 rounded-2xl text-slate-400 dark:text-slate-500">
                  <UploadCloud size={32} />
                </div>
                
                <div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                    {file ? file.name : 'Select file or drop it here'}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">Accepts PDF, TXT, image snaps (Max size: 10MB)</p>
                </div>
              </div>

              {/* Subject Tag Selector */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5 font-bold">Subject Tag</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 text-slate-800 dark:text-slate-100 text-xs focus:ring-1 focus:ring-cyan-500 outline-none"
                >
                  {SUBJECTS.map((s, idx) => (
                    <option key={idx} value={s} className="bg-white text-slate-800 dark:bg-slate-900 dark:text-slate-100">{s}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={!file}
                className="w-full p-3.5 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-xl text-white font-bold text-xs uppercase tracking-wider hover:opacity-90 disabled:opacity-50 transition-all flex items-center justify-center gap-1.5 shadow-cyan-glow"
              >
                <FileCheck size={14} />
                <span>Upload & OCR Extractor</span>
              </button>

            </form>
          </div>
        </div>

        {/* Right Side: Library List (Span 1) */}
        <div className="p-6 rounded-2xl glass-panel space-y-4">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
            Study Library ({uploads.length})
          </h3>
          
          {uploads.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8 leading-normal">
              No files uploaded yet. Drag slides or slide PDFs into the dropzone to start learning.
            </p>
          ) : (
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {uploads.map(up => (
                <div key={up._id} className="p-3 bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between items-start gap-2">
                    <div className="overflow-hidden flex-1">
                      <p className="font-semibold text-slate-800 dark:text-slate-200 truncate" title={up.filename}>{up.filename}</p>
                      <span className="inline-block mt-1 px-2 py-0.5 bg-cyan-500/10 text-cyan-500 rounded text-[9px] font-bold uppercase">{up.subject}</span>
                    </div>
                    <button 
                      onClick={() => deleteUpload(up._id)}
                      className="text-slate-400 hover:text-red-400 transition-colors p-1"
                      title="Delete Upload"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                  
                  {/* Action row */}
                  <div className="flex gap-2 pt-1 border-t border-slate-100 dark:border-white/5">
                    <button
                      onClick={() => handleStartChat(up)}
                      className="flex-1 py-1 px-2 bg-cyan-500/10 text-cyan-500 hover:bg-cyan-500/20 rounded text-[10px] font-semibold transition-all flex items-center justify-center gap-1"
                    >
                      <MessageSquare size={10} />
                      <span>Chat</span>
                    </button>
                    <button
                      onClick={() => handleGenerateOutline(up._id)}
                      className="flex-1 py-1 px-2 bg-purple-500/10 text-purple-500 hover:bg-purple-500/20 rounded text-[10px] font-semibold transition-all flex items-center justify-center gap-1"
                    >
                      <BrainCircuit size={10} />
                      <span>Generate</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
