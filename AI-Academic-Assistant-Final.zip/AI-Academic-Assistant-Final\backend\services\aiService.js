const { GoogleGenerativeAI } = require('@google/generative-ai');
const pdfParse = require('pdf-parse');

/**
 * Helper to initialize GoogleGenerativeAI instance dynamically using client key or process.env.GEMINI_API_KEY
 */
function getGenAI(clientApiKey) {
  const apiKey = clientApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('Gemini API Key is not configured. Please add your key in the Settings page or backend .env file.');
  }
  return new GoogleGenerativeAI(apiKey);
}

/**
 * Extract text from PDF using Gemini multimodal vision first, falling back to local pdf-parse
 */
async function extractTextFromPDF(fileBuffer, clientApiKey = null) {
  try {
    const genAIInstance = getGenAI(clientApiKey);
    const model = genAIInstance.getGenerativeModel({ model: 'gemini-2.5-flash' });
    const docPart = {
      inlineData: {
        data: fileBuffer.toString('base64'),
        mimeType: 'application/pdf'
      }
    };
    const prompt = `
      Please extract all raw text contents, formulas, definitions, headings, and data from this PDF file.
      Output everything as clean, unsummarized text content so it can be structured for study guides.
    `;
    const result = await model.generateContent([prompt, docPart]);
    const extracted = result.response.text();
    if (extracted && extracted.trim().length > 100) {
      return extracted;
    }
  } catch (err) {
    console.warn('Gemini PDF parser failed or was blocked. Trying local pdf-parse library...', err.message);
  }

  // Local fallback
  try {
    const data = await pdfParse(fileBuffer);
    return data.text;
  } catch (err) {
    console.error('Local pdf-parse library failed to extract text:', err.message);
    throw new Error('PDF file could not be parsed or contains no readable text.');
  }
}

/**
 * OCR text extraction from document image or handwritten note
 */
async function performOCR(fileBuffer, fileType, clientApiKey = null) {
  const genAIInstance = getGenAI(clientApiKey);
  const model = genAIInstance.getGenerativeModel({ model: 'gemini-2.5-flash' });
  const imagePart = {
    inlineData: {
      data: fileBuffer.toString('base64'),
      mimeType: fileType
    }
  };
  const prompt = 'Extract all handwritten and printed text from this image. Clean up formatting and compile it into a legible academic text. Do not summarize; write all the contents exactly as shown.';
  const result = await model.generateContent([prompt, imagePart]);
  return result.response.text();
}

/**
 * Generate academic content (Notes, Formulas, MCQs, Flashcards, Mind Map) from document text
 */
async function generateNotes(text, mode = 'detailed', subject = 'General', clientApiKey = null) {
  const cleanText = text ? text.substring(0, 15000) : 'No content extracted.';
  const genAIInstance = getGenAI(clientApiKey);
  const model = genAIInstance.getGenerativeModel({ model: 'gemini-2.5-flash' });
  
  const prompt = `
    You are an elite academic assistant and subject tutor.
    Analyze the following text extracted from a study material (Subject: ${subject}) and generate a complete study bundle under the mode: "${mode}".
    
    Provide the output STRICTLY in a JSON format matching this exact schema:
    {
      "title": "A short descriptive title for these notes",
      "summary": "Generate a detailed, comprehensive chapter summary of the material (at least 200-300 words). Breakdown key sections.",
      "notesContent": "Generate highly detailed study notes covering all key concepts from the source material in beautiful Markdown. IMPORTANT: At the end of the notes, add a section called '## Important Exam Questions' with a list of 5-10 potential exam questions and brief answers derived from the material.",
      "keyPoints": ["At least 5 detailed key points representing core concepts in the text"],
      "formulas": ["A list of all key equations, math models, or core formulas found in the text. Format them clearly (e.g. Formula: Description)"],
      "definitions": [{"term": "concept name", "definition": "simple, clear explanation"}],
      "flashcards": [{"question": "A revision question testing core terminology?", "answer": "The answer to the question (concise)"}],
      "mcqs": [
        {
          "question": "A multiple choice practice question testing student understanding?",
          "options": ["Option A", "Option B", "Option C", "Option D"],
          "answerIndex": 0,
          "explanation": "Detailed explanation of why the correct option is true."
        }
      ],
      "mindmap": "A visual ASCII mind map drawing out concepts and relationships"
    }

    Requirements:
    1. Generate at least 5 flashcards.
    2. Generate at least 5 multiple choice questions in the mcqs array.
    3. Make sure all formulas, terms, and outlines are rich and accurate based on the context.

    Text Content:
    ${cleanText}
  `;

  const result = await model.generateContent(prompt);
  const responseText = result.response.text();
  
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    return JSON.parse(jsonMatch[0]);
  }
  return JSON.parse(responseText);
}

/**
 * Chat with Gemini model based on document context and session history
 */
async function chatWithDocument(documentText, userMessage, history = [], sourceNoteName = null, clientApiKey = null) {
  const cleanContext = documentText ? documentText.substring(0, 10000) : '';
  const genAIInstance = getGenAI(clientApiKey);
  const model = genAIInstance.getGenerativeModel({ model: 'gemini-2.5-flash' });
  
  const conversationHistory = history.map(h => `${h.sender === 'student' ? 'Student' : 'Tutor'}: ${h.text}`).join('\n');
  
  const prompt = `
    You are a highly capable AI Academic Tutor. Answer the student's question according to the following directives:
    
    1. GREETINGS & CHITCHAT: If the student greets you (e.g., "hi", "hello", "hey", "how are you"), reply warmly, introduce yourself as the StudySync AI assistant, and ask what academic concepts they want to tackle today. Do not try to reference notes or force study guide details for simple hello messages.
    
    2. GENERAL CONCEPTS: If the student asks general questions (e.g., "what is gravity?", "why is photosynthesis important?", "2+2 what"), answer them clearly, academically, and accurately.
    
    3. STUDY NOTES QUERY (Grounded answers):
       - If document context is provided below, prioritize searching for the answer inside that text.
       - If the answer is found in the context, formulate a thorough response, and explicitly specify the source note filename: "${sourceNoteName || 'uploaded notes'}". For example: "According to the uploaded guide [${sourceNoteName || 'Notes'}], ..."
       - If the answer is NOT in the document context but is still an academic study question, use your general knowledge to explain it thoroughly, but explicitly mention that this specific detail was not found in the uploaded document "${sourceNoteName || 'notes'}".
    
    4. RESPONSE QUALITY: Make your answers structured, complete, and easy to read. Use bullet points, bolding, and code/math formatting where appropriate.
    
    Document Context:
    ${cleanContext || 'No document context loaded.'}

    Recent Chat History:
    ${conversationHistory || 'None'}

    Student's Question:
    ${userMessage}
  `;

  console.log('-------------------------------------------');
  console.log('[AI CHAT REQUEST]');
  console.log('User Message:', userMessage);
  console.log('Request Sent to Gemini (Prompt):\n', prompt);
  
  const result = await model.generateContent(prompt);
  const responseText = result.response.text();
  
  console.log('Raw Gemini Response:\n', responseText);
  console.log('Final Response Returned to Frontend:\n', responseText);
  console.log('-------------------------------------------');

  return responseText;
}

module.exports = {
  extractTextFromPDF,
  performOCR,
  generateNotes,
  chatWithDocument
};
