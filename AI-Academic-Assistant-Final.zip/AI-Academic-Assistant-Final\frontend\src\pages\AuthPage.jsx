import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  GraduationCap, 
  Sparkles, 
  Lock, 
  Mail, 
  User, 
  School, 
  BookOpen, 
  ArrowRight,
  ShieldAlert,
  KeyRound,
  CheckCircle2
} from 'lucide-react';

export default function AuthPage({ navigate, initialSignUp = false }) {
  const { login, register, forgotPassword, resetPassword, authError } = useApp();
  
  // Auth Modes: 'login', 'signup', 'forgot', 'reset'
  const [authMode, setAuthMode] = useState(initialSignUp ? 'signup' : 'login');
  
  // Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [college, setCollege] = useState('');
  const [department, setDepartment] = useState('');
  const [year, setYear] = useState('');
  
  // Forgot / Reset fields
  const [resetToken, setResetTokenState] = useState('');
  const [newPassword, setNewPassword] = useState('');
  
  // UI states
  const [submitting, setSubmitting] = useState(false);
  const [localError, setLocalError] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    setLocalError('');
    setStatusMsg('');
    setSubmitting(true);
    
    try {
      if (authMode === 'signup') {
        const success = await register(name, email, password, college, department, year);
        if (success) {
          navigate('dashboard');
        }
      } else if (authMode === 'login') {
        const success = await login(email, password);
        if (success) {
          navigate('dashboard');
        }
      } else if (authMode === 'forgot') {
        const res = await forgotPassword(email);
        if (res.success) {
          setStatusMsg(`Reset code generated successfully! For local testing, code is: ${res.token}`);
          setResetTokenState(res.token); // Prefill the code
          setAuthMode('reset');
        } else {
          setLocalError(res.error || 'Failed to initiate password reset.');
        }
      } else if (authMode === 'reset') {
        const res = await resetPassword(email, resetToken, newPassword);
        if (res.success) {
          setStatusMsg('Password updated successfully. You can now login.');
          setAuthMode('login');
          setPassword(''); // clear password field
        } else {
          setLocalError(res.error || 'Failed to reset password.');
        }
      }
    } catch (err) {
      setLocalError('An unexpected error occurred. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex-1 w-full flex items-center justify-center py-16 px-4 relative min-h-screen">
      
      {/* Background radial effects */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[20%] left-[10%] w-[40%] h-[40%] bg-glow-purple opacity-30 dark:opacity-50 rounded-full"></div>
        <div className="absolute bottom-[20%] right-[10%] w-[40%] h-[40%] bg-glow-cyan opacity-20 dark:opacity-30 rounded-full"></div>
      </div>

      <div className="w-full max-w-xl glass-panel p-8 sm:p-10 rounded-2xl relative z-10 shadow-2xl space-y-6">
        
        {/* Branding */}
        <div className="text-center space-y-2">
          <div className="inline-flex p-3 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-2xl shadow-cyan-glow mb-2">
            <GraduationCap className="text-white" size={32} />
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            StudySync <span className="gradient-text font-extrabold">Portal</span>
          </h2>
          <p className="text-xs text-slate-400">
            {authMode === 'signup' && 'Create your student account to unlock AI study accelerators'}
            {authMode === 'login' && 'Access your notes, flashcards, and chatbots'}
            {authMode === 'forgot' && 'Retrieve your account access credentials'}
            {authMode === 'reset' && 'Create a new secure password for your account'}
          </p>
        </div>

        {/* Status / Success Messages */}
        {statusMsg && (
          <div className="p-3.5 bg-green-500/15 border border-green-500/30 text-green-300 rounded-xl text-xs flex items-center gap-2">
            <CheckCircle2 size={16} className="shrink-0 text-green-400" />
            <span>{statusMsg}</span>
          </div>
        )}

        {/* Auth error alerts */}
        {(authError || localError) && (
          <div className="p-3.5 bg-red-500/15 border border-red-500/30 text-red-300 rounded-xl text-xs flex items-center gap-2">
            <ShieldAlert size={16} className="shrink-0 text-red-400" />
            <span>{authError || localError}</span>
          </div>
        )}

        {/* Main form */}
        <form onSubmit={handleAuthSubmit} className="space-y-4 text-left">
          
          {/* signup fields */}
          {authMode === 'signup' && (
            <>
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3 text-slate-500" size={16} />
                  <input 
                    type="text" required value={name} onChange={e => setName(e.target.value)}
                    placeholder="e.g. Alex Mercer" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">School / College</label>
                  <div className="relative">
                    <School className="absolute left-3.5 top-3 text-slate-500" size={16} />
                    <input 
                      type="text" value={college} onChange={e => setCollege(e.target.value)}
                      placeholder="e.g. State Tech" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">Department</label>
                  <div className="relative">
                    <BookOpen className="absolute left-3.5 top-3 text-slate-500" size={16} />
                    <input 
                      type="text" value={department} onChange={e => setDepartment(e.target.value)}
                      placeholder="e.g. Computer Science" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">Year / Semester</label>
                <input 
                  type="text" value={year} onChange={e => setYear(e.target.value)}
                  placeholder="e.g. 3rd Year - Sem 5" className="w-full p-3 rounded-xl glass-input text-xs"
                />
              </div>
            </>
          )}

          {/* Email input field - needed for all modes */}
          <div>
            <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3 text-slate-500" size={16} />
              <input 
                type="email" required value={email} onChange={e => setEmail(e.target.value)}
                placeholder="student@academic.edu" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
              />
            </div>
          </div>

          {/* Login / signup password */}
          {(authMode === 'login' || authMode === 'signup') && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-[10px] uppercase tracking-wider text-slate-400 font-bold">Password</label>
                {authMode === 'login' && (
                  <button 
                    type="button" 
                    onClick={() => {
                      setLocalError('');
                      setStatusMsg('');
                      setAuthMode('forgot');
                    }}
                    className="text-[10px] text-cyan-400 hover:underline"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3 text-slate-500" size={16} />
                <input 
                  type="password" required value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                />
              </div>
            </div>
          )}

          {/* Reset password fields */}
          {authMode === 'reset' && (
            <>
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">Verification Reset Code</label>
                <div className="relative">
                  <KeyRound className="absolute left-3.5 top-3 text-slate-500" size={16} />
                  <input 
                    type="text" required value={resetToken} onChange={e => setResetTokenState(e.target.value)}
                    placeholder="6-CHARACTER CODE" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs font-mono uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-400 mb-1 font-bold">New Password</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 text-slate-500" size={16} />
                  <input 
                    type="password" required value={newPassword} onChange={e => setNewPassword(e.target.value)}
                    placeholder="••••••••" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full p-3.5 bg-gradient-to-r from-cyan-500 via-purple-600 to-indigo-600 rounded-xl text-white font-bold text-xs uppercase tracking-wider shadow-cyan-glow hover:opacity-90 disabled:opacity-50 transition-all flex items-center justify-center gap-1.5"
          >
            <span>
              {submitting ? 'Processing...' : 
                authMode === 'login' ? 'Authenticate Session' :
                authMode === 'signup' ? 'Create Student Account' :
                authMode === 'forgot' ? 'Generate Reset Code' :
                'Update Account Password'
              }
            </span>
            <ArrowRight size={14} />
          </button>
        </form>

        {/* Alternate navigation choices */}
        <div className="pt-4 border-t border-white/5 text-center text-xs text-slate-400 flex flex-col gap-2">
          {authMode === 'login' && (
            <p>First time here? <button onClick={() => { setLocalError(''); setStatusMsg(''); setAuthMode('signup'); }} className="text-cyan-400 underline font-semibold ml-1">Sign up free</button></p>
          )}
          {authMode === 'signup' && (
            <p>Already registered? <button onClick={() => { setLocalError(''); setStatusMsg(''); setAuthMode('login'); }} className="text-cyan-400 underline font-semibold ml-1">Login here</button></p>
          )}
          {(authMode === 'forgot' || authMode === 'reset') && (
            <p>Remembered your password? <button onClick={() => { setLocalError(''); setStatusMsg(''); setAuthMode('login'); }} className="text-cyan-400 underline font-semibold ml-1">Back to Login</button></p>
          )}
        </div>

      </div>
    </div>
  );
}
