import React from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  Sparkles, 
  UploadCloud, 
  FileText, 
  BrainCircuit, 
  Timer, 
  BookOpen, 
  Trophy, 
  Flame, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';

export default function DashboardPage({ navigate }) {
  const { user, uploads, notes, incrementStreak } = useApp();

  const handleClaimStreak = async () => {
    await incrementStreak();
  };

  const getRecentUploads = () => {
    return uploads.slice(0, 4);
  };

  const getRecentNotes = () => {
    return notes.slice(0, 4);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-7xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header Greeting */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-sans">
            Welcome Back, <span className="gradient-text font-extrabold">{user?.name || 'Student'}</span>!
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Accelerate your university learning curves using custom Gemini structures.</p>
        </div>
        
        {/* Streak Button */}
        <button
          onClick={handleClaimStreak}
          className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all self-start md:self-auto"
        >
          <Flame size={16} className="animate-pulse" />
          <span>Claim Daily Streak</span>
        </button>
      </div>

      {/* Analytics widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Card 1: Streak */}
        <div className="p-6 rounded-2xl glass-panel flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">Daily Streak</span>
            <p className="text-2xl font-extrabold font-outfit">{user?.studyStats?.streak || 1} Days</p>
          </div>
          <div className="p-3 bg-orange-500/10 text-orange-500 rounded-xl border border-orange-500/20">
            <Flame size={20} />
          </div>
        </div>

        {/* Card 2: Study Hours */}
        <div className="p-6 rounded-2xl glass-panel flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">Focus Time</span>
            <p className="text-2xl font-extrabold font-outfit">{user?.studyStats?.studyHours?.toFixed(2) || '0.00'} hrs</p>
          </div>
          <div className="p-3 bg-cyan-500/10 text-cyan-500 rounded-xl border border-cyan-500/20">
            <Timer size={20} />
          </div>
        </div>

        {/* Card 3: Library uploads */}
        <div className="p-6 rounded-2xl glass-panel flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">Study Materials</span>
            <p className="text-2xl font-extrabold font-outfit">{uploads.length} Files</p>
          </div>
          <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl border border-purple-500/20">
            <BookOpen size={20} />
          </div>
        </div>

        {/* Card 4: Quizzes Completed */}
        <div className="p-6 rounded-2xl glass-panel flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">Quizzes Passed</span>
            <p className="text-2xl font-extrabold font-outfit">{user?.studyStats?.quizScores?.length || 0} Tests</p>
          </div>
          <div className="p-3 bg-green-500/10 text-green-500 rounded-xl border border-green-500/20">
            <Trophy size={20} />
          </div>
        </div>

      </div>

      {/* Grid: recent docs & direct shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: shortcuts & lists (Span 2) */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Recent Uploaded documents */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200/50 dark:border-white/5">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <UploadCloud size={16} className="text-cyan-400" />
                <span>Recently Uploaded Study Materials</span>
              </h3>
              {uploads.length > 0 && (
                <button onClick={() => navigate('upload')} className="text-xs text-cyan-500 dark:text-cyan-400 hover:underline flex items-center gap-1">
                  <span>View All</span>
                  <ArrowRight size={12} />
                </button>
              )}
            </div>
            
            {uploads.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No materials uploaded yet. Go to <button onClick={() => navigate('upload')} className="text-cyan-400 underline font-semibold ml-1">Upload Notes</button> to begin.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {getRecentUploads().map(up => (
                  <div key={up._id} className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 flex items-start gap-3 hover:border-cyan-500/30 transition-all">
                    <div className="p-2 bg-cyan-500/10 text-cyan-500 rounded-lg">
                      <FileText size={16} />
                    </div>
                    <div className="overflow-hidden flex-1">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{up.filename}</p>
                      <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-wider">{up.subject}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Generated Study Outlines */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200/50 dark:border-white/5">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <FileText size={16} className="text-purple-400" />
                <span>AI Study Guides & Outlines</span>
              </h3>
              {notes.length > 0 && (
                <button onClick={() => navigate('short-notes')} className="text-xs text-cyan-500 dark:text-cyan-400 hover:underline flex items-center gap-1">
                  <span>View All</span>
                  <ArrowRight size={12} />
                </button>
              )}
            </div>
            
            {notes.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No study guides generated yet. Upload a slide deck/PDF and run outline generator to review guides here.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {getRecentNotes().map(n => (
                  <div key={n._id} className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 flex items-start gap-3 hover:border-purple-500/30 transition-all">
                    <div className="p-2 bg-purple-500/10 text-purple-500 rounded-lg">
                      <BrainCircuit size={16} />
                    </div>
                    <div className="overflow-hidden flex-1">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{n.title}</p>
                      <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-wider">{n.subject}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Right Column: shortcuts & widgets (Span 1) */}
        <div className="space-y-6">
          
          {/* Quick study tools routes */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
              Study Hub Shortcuts
            </h3>
            <div className="grid grid-cols-2 gap-3 text-center text-xs">
              <button 
                onClick={() => navigate('chat')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 hover:border-cyan-500/20 transition-all space-y-2 flex flex-col items-center"
              >
                <Sparkles className="text-cyan-400" size={18} />
                <span>AI Chat</span>
              </button>
              <button 
                onClick={() => navigate('quiz')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 hover:border-purple-500/20 transition-all space-y-2 flex flex-col items-center"
              >
                <BrainCircuit className="text-purple-400" size={18} />
                <span>Practice Quiz</span>
              </button>
              <button 
                onClick={() => navigate('flashcards')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 hover:border-pink-500/20 transition-all space-y-2 flex flex-col items-center"
              >
                <Trophy className="text-pink-400" size={18} />
                <span>Flashcards</span>
              </button>
              <button 
                onClick={() => navigate('study-planner')}
                className="p-4 rounded-xl bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 hover:border-orange-500/20 transition-all space-y-2 flex flex-col items-center"
              >
                <Timer className="text-orange-400" size={18} />
                <span>Study Planner</span>
              </button>
            </div>
          </div>

          {/* Streaks progress status */}
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
              Streak Achievement
            </h3>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-500/10 text-amber-500 rounded-xl border border-amber-500/20">
                <Trophy size={20} />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">Study streak: {user?.studyStats?.streak || 1} Days</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Study daily and take quizzes to unlock higher streak statuses.</p>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
