import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  CalendarRange, 
  Timer, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  CheckCircle,
  Check
} from 'lucide-react';

const POMODORO_WORK = 25 * 60; // 25 minutes
const POMODORO_BREAK = 5 * 60; // 5 minutes

export default function StudyToolsPage() {
  const { tasks, createTask, updateTask, deleteTask, logStudyTime } = useApp();
  
  // Task Planner Local state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubject, setTaskSubject] = useState('General');
  
  // Pomodoro Local state
  const [timerSeconds, setTimerSeconds] = useState(POMODORO_WORK);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerMode, setTimerMode] = useState('work'); // 'work' or 'break'
  
  useEffect(() => {
    let interval = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(prev => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      handleTimerComplete();
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  const handleTimerComplete = () => {
    setIsTimerRunning(false);
    
    // Play synthesizer beep
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance("Focus interval completed. Take a study break.");
      utterance.rate = 1.1;
      window.speechSynthesis.speak(utterance);
    }

    if (timerMode === 'work') {
      // Log study time: 25 minutes = 0.42 hours
      logStudyTime(0.42);
      alert("Great job focusing! 25 minutes logged. Time for a 5 minute break!");
      setTimerMode('break');
      setTimerSeconds(POMODORO_BREAK);
    } else {
      alert("Break over! Time to focus again.");
      setTimerMode('work');
      setTimerSeconds(POMODORO_WORK);
    }
  };

  const handleTaskSubmit = (e) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    createTask(taskTitle.trim(), taskSubject);
    setTaskTitle('');
  };

  const handleToggleTask = (id, currentVal) => {
    updateTask(id, !currentVal);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-5xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
          <CalendarRange size={28} className="text-orange-400" />
          <span>Study Accel Planner</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Organize lecture tasks and lock focus intervals with Pomodoro timers.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Left Side: Tasks Planner */}
        <div className="p-6 rounded-2xl glass-panel space-y-6">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
            Weekly Study Milestones
          </h3>

          <form onSubmit={handleTaskSubmit} className="flex gap-2">
            <input 
              type="text"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              placeholder="e.g. Solve Neural Net derivatives..."
              className="flex-1 p-2.5 rounded-xl glass-input text-xs"
            />
            <button 
              type="submit"
              className="p-2.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-xl hover:opacity-90 transition-all flex items-center justify-center"
            >
              <Plus size={16} />
            </button>
          </form>

          {/* Tasks List */}
          {tasks.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8 italic">No planner tasks. Create some milestones above.</p>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {tasks.map(t => (
                <div 
                  key={t._id}
                  className={`
                    p-3 bg-white dark:bg-white/5 border rounded-xl flex items-center justify-between text-xs transition-all
                    ${t.completed ? 'border-slate-100 dark:border-white/5 opacity-60' : 'border-slate-200/80 dark:border-white/5'}
                  `}
                >
                  <button 
                    onClick={() => handleToggleTask(t._id, t.completed)}
                    className="flex items-center gap-3 text-left overflow-hidden flex-1"
                  >
                    {t.completed ? (
                      <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                    ) : (
                      <Circle size={16} className="text-slate-400 shrink-0" />
                    )}
                    <span className={`truncate text-slate-800 dark:text-slate-200 font-medium ${t.completed ? 'line-through' : ''}`}>{t.title}</span>
                  </button>
                  
                  <button 
                    onClick={() => deleteTask(t._id)}
                    className="text-slate-400 hover:text-red-400 p-1"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Side: Pomodoro Clock */}
        <div className="p-6 rounded-2xl glass-panel space-y-6 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2 flex items-center gap-2">
              <Timer size={16} className="text-orange-400 animate-pulse" />
              <span>Pomodoro Study Clock</span>
            </h3>
            <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">
              Lock focus intervals using 25-minute study stretches. Completed slots award streak points and automatically log study time.
            </p>
          </div>

          {/* Clock Display */}
          <div className="py-8 text-center space-y-2">
            <span className="text-6xl font-extrabold text-slate-800 dark:text-white font-mono tracking-wider">
              {formatTime(timerSeconds)}
            </span>
            <p className="text-[10px] text-orange-400 font-bold uppercase tracking-widest">
              {timerMode === 'work' ? '🔥 Focus Interval active' : '💤 Break Interval active'}
            </p>
          </div>

          {/* Buttons Row */}
          <div className="flex gap-3 justify-center pt-2">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shadow-md text-white ${isTimerRunning ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}`}
            >
              {isTimerRunning ? <Pause size={14} /> : <Play size={14} />}
              <span>{isTimerRunning ? 'Pause Clock' : 'Start Focus'}</span>
            </button>
            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerSeconds(timerMode === 'work' ? POMODORO_WORK : POMODORO_BREAK);
              }}
              className="p-2.5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 hover:border-slate-300 rounded-xl text-slate-600 dark:text-slate-350 transition-all"
            >
              <RotateCcw size={14} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
