import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  Mail, 
  Send, 
  CheckCircle2, 
  HelpCircle, 
  Bug, 
  Lightbulb, 
  ArrowRight 
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function ContactPage() {
  const { user } = useApp();

  // Form Fields
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [category, setCategory] = useState('Bug Report');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitting(true);

    // Simulate sending support request
    setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
      setMessage('');
      confetti({ particleCount: 50, spread: 60 });
      setTimeout(() => setSuccess(false), 5000);
    }, 1000);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-4xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
          <Mail size={28} className="text-cyan-400" />
          <span>Support & Feedback</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Submit bug reports, feature suggestions, or ask general support questions.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Side: Support Form (Span 2) */}
        <div className="md:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl glass-panel space-y-6">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
              Send Message to Support
            </h3>

            {success && (
              <div className="p-3.5 bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                <span>Message sent successfully! Our academic support team will review it.</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Your Name</label>
                  <input 
                    type="text" required value={name} onChange={e => setName(e.target.value)}
                    placeholder="e.g. Alex Mercer" className="w-full p-2.5 rounded-xl glass-input text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Email Address</label>
                  <input 
                    type="email" required value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="student@academic.edu" className="w-full p-2.5 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5 font-bold">Feedback Category</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'Bug Report', label: 'Bug Report', icon: Bug },
                    { id: 'Feature Idea', label: 'Feature Idea', icon: Lightbulb },
                    { id: 'Get Help', label: 'Get Help', icon: HelpCircle }
                  ].map(cat => {
                    const Icon = cat.icon;
                    const isSelected = category === cat.id;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setCategory(cat.id)}
                        className={`
                          p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all text-[10px] font-bold uppercase
                          ${isSelected 
                            ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-600 dark:text-cyan-300 font-bold' 
                            : 'bg-white dark:bg-white/5 border-slate-200/60 dark:border-white/5 text-slate-500 hover:text-slate-700 dark:hover:text-slate-350'
                          }
                        `}
                      >
                        <Icon size={16} />
                        <span>{cat.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Message Content</label>
                <textarea 
                  required rows={5} value={message} onChange={e => setMessage(e.target.value)}
                  placeholder="Describe your issue or suggestions in detail..."
                  className="w-full p-3 rounded-xl glass-input text-xs resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="px-5 py-3 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold hover:opacity-90 disabled:opacity-50 transition-all flex items-center gap-1.5 shadow-cyan-glow"
              >
                {submitting ? (
                  <span>Sending...</span>
                ) : (
                  <>
                    <span>Submit Ticket</span>
                    <Send size={12} />
                  </>
                )}
              </button>

            </form>
          </div>
        </div>

        {/* Right Side: Quick Contact Info (Span 1) */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl glass-panel space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
              University Support
            </h3>
            
            <div className="space-y-4 text-xs">
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                If you encounter any server problems or API token limitations, feel free to open a ticket or drop an email directly.
              </p>
              
              <div className="space-y-2 border-t border-slate-100 dark:border-white/5 pt-4">
                <div>
                  <p className="text-[9px] uppercase text-slate-450 dark:text-slate-400 font-bold">Email Support</p>
                  <p className="text-cyan-500 dark:text-cyan-400 font-semibold font-mono">support@studysync.edu</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase text-slate-450 dark:text-slate-400 font-bold">Operating Hours</p>
                  <p className="text-slate-800 dark:text-slate-350">Mon - Fri: 9:00 AM - 5:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
