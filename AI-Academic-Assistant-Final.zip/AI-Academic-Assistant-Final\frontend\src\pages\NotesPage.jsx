import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  FileText, 
  BookOpen, 
  Bookmark, 
  Trash2, 
  Sparkles,
  HelpCircle,
  Heading1,
  Layers,
  Sigma
} from 'lucide-react';

export default function NotesPage({ initialTab = 'summary' }) {
  const { notes, activeNote, setActiveNote, deleteNote } = useApp();
  const [activeTab, setActiveTab] = useState(initialTab);

  if (notes.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto text-center space-y-6 px-6 py-20 bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
        <div className="w-16 h-16 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-cyan-glow text-white">
          <FileText size={32} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white font-sans">No Outlines Generated Yet</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed font-sans">
            Go to Upload Notes, drop your slide decks, and click "Generate" to compile notes, formulas, and flashcards.
          </p>
        </div>
      </div>
    );
  }

  const currentNote = activeNote || notes[0];

  const tabs = [
    { id: 'summary', label: 'Chapter Summary', icon: FileText },
    { id: 'notes', label: 'Detailed Outlines', icon: BookOpen },
    { id: 'definitions', label: 'Definitions Glossary', icon: Bookmark },
    { id: 'formulas', label: 'Equation Sheet', icon: Sigma },
    { id: 'mindmap', label: 'ASCII Mind Map', icon: Layers }
  ];

  const handleSelectNote = (nRecord) => {
    setActiveNote(nRecord);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-7xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div className="flex justify-between items-center pb-3 border-b border-slate-200/50 dark:border-white/5">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
            <BookOpen size={28} className="text-purple-400" />
            <span>AI Study Library</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Review summaries, detailed study notes, and equation books compiled from slides.</p>
        </div>
        
        <button 
          onClick={() => deleteNote(currentNote._id)}
          className="p-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs font-bold transition-all flex items-center gap-1.5"
          title="Delete Outline"
        >
          <Trash2 size={14} />
          <span>Delete Guide</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Side: Outlines List Selector (Span 1) */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Outlines Repository</h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {notes.map(n => (
              <button
                key={n._id}
                onClick={() => handleSelectNote(n)}
                className={`
                  w-full p-4 rounded-xl text-left text-xs transition-all flex items-start gap-3 border
                  ${currentNote._id === n._id 
                    ? 'bg-purple-500/10 border-purple-500/30 text-purple-600 dark:text-purple-300 font-semibold' 
                    : 'bg-white dark:bg-white/5 border-slate-200/60 dark:border-white/5 text-slate-700 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10'
                  }
                `}
              >
                <div className={`p-2 rounded-lg ${currentNote._id === n._id ? 'bg-purple-500/20 text-purple-500' : 'bg-slate-100 dark:bg-white/5 text-slate-400'}`}>
                  <FileText size={14} />
                </div>
                <div className="overflow-hidden flex-1">
                  <p className="font-semibold truncate">{n.title}</p>
                  <span className="inline-block mt-1 text-[9px] uppercase font-bold tracking-widest text-slate-400">{n.subject}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Side: Tab Panel Content (Span 3) */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Tab Ribbon */}
          <div className="flex flex-wrap gap-2 border-b border-slate-200/50 dark:border-white/5 pb-2 overflow-x-auto">
            {tabs.map(t => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`
                    px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border shrink-0
                    ${isActive 
                      ? 'bg-gradient-to-r from-cyan-500 to-indigo-500 border-none text-white shadow-cyan-glow' 
                      : 'bg-white dark:bg-white/5 border-slate-200/60 dark:border-white/5 text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                    }
                  `}
                >
                  <Icon size={14} />
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Views */}
          <div className="p-6 rounded-2xl glass-panel min-h-[300px]">
            {activeTab === 'summary' && (
              <div className="space-y-4">
                <h2 className="text-lg font-bold font-sans text-slate-800 dark:text-slate-100 border-b border-slate-200/50 dark:border-white/5 pb-2">
                  Chapter Executive Summary
                </h2>
                <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-350 whitespace-pre-wrap">
                  {currentNote.summary || 'No summary compiled.'}
                </p>
              </div>
            )}

            {activeTab === 'notes' && (
              <div className="space-y-4 text-xs leading-relaxed text-slate-700 dark:text-slate-300">
                <h2 className="text-lg font-bold font-sans text-slate-800 dark:text-slate-100 border-b border-slate-200/50 dark:border-white/5 pb-2">
                  Academic Lecture Notes
                </h2>
                {/* Outlines can render structured lists, bold headings, and sub-items */}
                <div className="whitespace-pre-line text-slate-700 dark:text-slate-300 font-medium">
                  {currentNote.notesContent || 'No outline generated.'}
                </div>
              </div>
            )}

            {activeTab === 'definitions' && (
              <div className="space-y-4">
                <h2 className="text-lg font-bold font-sans text-slate-800 dark:text-slate-100 border-b border-slate-200/50 dark:border-white/5 pb-2">
                  Definitions & Terminology Glossary
                </h2>
                {(!currentNote.definitions || currentNote.definitions.length === 0) ? (
                  <p className="text-xs text-slate-400 italic">No glossary definitions compiled in this guide.</p>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {currentNote.definitions.map((def, idx) => (
                      <div key={idx} className="p-4 bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 rounded-xl space-y-1">
                        <strong className="text-xs text-cyan-500 dark:text-cyan-400 font-bold uppercase tracking-wider">{def.term}</strong>
                        <p className="text-xs text-slate-700 dark:text-slate-350 leading-relaxed">{def.definition}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'formulas' && (
              <div className="space-y-4">
                <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 border-b border-slate-200/50 dark:border-white/5 pb-2">
                  Formula Sheet & Formulas Index
                </h2>
                {(!currentNote.formulas || currentNote.formulas.length === 0) ? (
                  <p className="text-xs text-slate-400 italic">No formulas or equations parsed from slides.</p>
                ) : (
                  <div className="space-y-3">
                    {currentNote.formulas.map((form, idx) => (
                      <div key={idx} className="p-3 bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 rounded-xl font-mono text-xs flex items-center gap-3">
                        <span className="p-1.5 bg-cyan-500/10 text-cyan-500 rounded font-bold font-sans"># {idx+1}</span>
                        <span className="text-slate-800 dark:text-slate-200">{form}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'mindmap' && (
              <div className="space-y-4">
                <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 border-b border-slate-200/50 dark:border-white/5 pb-2">
                  Visual Concept ASCII Mind Map
                </h2>
                <pre className="p-4 bg-slate-950 border border-white/5 rounded-xl font-mono text-[10px] text-cyan-300 overflow-x-auto leading-relaxed whitespace-pre shadow-inner">
                  {currentNote.mindmap || 'No concept map created.'}
                </pre>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
