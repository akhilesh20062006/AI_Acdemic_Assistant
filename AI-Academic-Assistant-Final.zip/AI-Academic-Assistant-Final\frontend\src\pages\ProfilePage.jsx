import React, { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  UserCircle2, 
  Sparkles, 
  School, 
  BookOpen, 
  Award, 
  TrendingUp, 
  Flame, 
  Clock, 
  Save,
  CheckCircle
} from 'lucide-react';

export default function ProfilePage() {
  const { user, uploads, notes, updateProfile } = useApp();

  // Edit fields
  const [college, setCollege] = useState(user?.college || '');
  const [department, setDepartment] = useState(user?.department || '');
  const [year, setYear] = useState(user?.year || '');
  
  const [isSaved, setIsSaved] = useState(false);

  const handleProfileSave = async (e) => {
    e.preventDefault();
    await updateProfile({ college, department, year });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const getBadges = () => {
    const list = [];
    
    // Badge 1: uploaded materials
    if (uploads.length > 0) {
      list.push({ title: "Quick Starter", desc: "Uploaded your first study guide to portal library", icon: Sparkles, color: "text-cyan-500 bg-cyan-500/10 border-cyan-500/20" });
    }
    // Badge 2: generated outlines
    if (notes.length > 0) {
      list.push({ title: "Outline Scholar", desc: "Generated a structured outline from lecture slides", icon: Award, color: "text-purple-400 bg-purple-500/10 border-purple-500/20" });
    }
    // Badge 3: focus hours
    if ((user?.studyStats?.studyHours || 0) > 0.5) {
      list.push({ title: "Focus Engine", desc: "Completed focus intervals and logged study hours", icon: Clock, color: "text-orange-500 bg-orange-500/10 border-orange-500/20" });
    }
    // Badge 4: streak days
    if ((user?.studyStats?.streak || 0) > 1) {
      list.push({ title: "Streak Master", desc: "Maintained learning streaks across consecutive days", icon: Flame, color: "text-amber-500 bg-amber-500/10 border-amber-500/20" });
    }

    return list;
  };

  const badgesList = getBadges();

  return (
    <div className="flex-1 p-6 md:p-8 space-y-8 max-w-5xl mx-auto w-full text-left bg-slate-50 dark:bg-[#070415] transition-colors duration-200">
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-sans flex items-center gap-2">
          <UserCircle2 size={28} className="text-cyan-400" />
          <span>Student Profile</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Review learning stats, details configuration, and unlocked academic milestone badges.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Side: Stats and Edit Info (Span 2) */}
        <div className="md:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl glass-panel space-y-6">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2">
              Academic Metadata Configuration
            </h3>

            {isSaved && (
              <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle size={14} className="text-green-500" />
                <span>Academic settings saved successfully.</span>
              </div>
            )}

            <form onSubmit={handleProfileSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Student Name</label>
                  <input type="text" disabled value={user?.name || ''} className="w-full p-3 rounded-xl glass-input text-xs opacity-60 cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Registered Email</label>
                  <input type="text" disabled value={user?.email || ''} className="w-full p-3 rounded-xl glass-input text-xs opacity-60 cursor-not-allowed" />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">School / University</label>
                <div className="relative">
                  <School className="absolute left-3.5 top-3.5 text-slate-500" size={16} />
                  <input 
                    type="text" value={college} onChange={e => setCollege(e.target.value)}
                    placeholder="e.g. State Tech" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Department</label>
                  <div className="relative">
                    <BookOpen className="absolute left-3.5 top-3.5 text-slate-500" size={16} />
                    <input 
                      type="text" value={department} onChange={e => setDepartment(e.target.value)}
                      placeholder="e.g. Computer Science" className="w-full pl-10 pr-4 py-3 rounded-xl glass-input text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1 font-bold">Year / Sem</label>
                  <input 
                    type="text" value={year} onChange={e => setYear(e.target.value)}
                    placeholder="e.g. 3rd Year" className="w-full p-3 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-5 py-3 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-xl text-xs font-bold hover:opacity-90 transition-all flex items-center gap-1.5 shadow-cyan-glow"
              >
                <Save size={14} />
                <span>Save Changes</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Side: Badges & Streaks */}
        <div className="p-6 rounded-2xl glass-panel space-y-6">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200/50 dark:border-white/5 pb-2 flex items-center gap-2">
            <Award size={16} className="text-cyan-400" />
            <span>Academic Achievements</span>
          </h3>

          {badgesList.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8 leading-normal">
              No milestones unlocked yet. Upload materials, generate outlines, and complete Pomodoro focus clock intervals to unlock streaks and badges.
            </p>
          ) : (
            <div className="space-y-4">
              {badgesList.map((bdg, idx) => {
                const Icon = bdg.icon;
                return (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-white dark:bg-white/5 border border-slate-200/60 dark:border-white/5 rounded-xl">
                    <div className={`p-2.5 rounded-xl border shrink-0 ${bdg.color}`}>
                      <Icon size={16} />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{bdg.title}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 leading-normal">{bdg.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
