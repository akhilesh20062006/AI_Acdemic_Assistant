import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  UploadCloud, 
  Brain, 
  Timer, 
  FileSearch, 
  LineChart, 
  GraduationCap, 
  ChevronDown, 
  Check, 
  ShieldCheck 
} from 'lucide-react';

export default function LandingPage({ triggerAuth }) {
  const [activeFaq, setActiveFaq] = useState(null);

  const features = [
    { title: 'AI Study Library', desc: 'Convert PDFs and slides to neat notes, formulas sheets, and ASCII mind maps.', icon: Brain },
    { title: 'Interactive Quizzes', desc: 'AI extracts MCQs and creates study flashcards with active recall testing.', icon: Sparkles },
    { title: 'Doubt Solving Chat', desc: 'Ask questions based strictly on the uploaded textbooks. Voice synthesis ready.', icon: FileSearch },
    { title: 'Pomodoro Focus Timer', desc: 'Built-in work-break timer with streak badge awards.', icon: Timer },
    { title: 'OCR Handwriting Reader', desc: 'Take photos of your notebooks; AI reads and cleans text to markdown notes.', icon: UploadCloud },
    { title: 'Smart Progress Analytics', desc: 'Monitor study time, daily learning streaks, and quiz test results.', icon: LineChart },
  ];

  const faqs = [
    { q: 'Which file formats are supported?', a: 'You can upload PDFs, PPT/PPTX slide decks, Word DOC/DOCX documents, plain TXT files, and handwritten study notebook images (JPEG, PNG).' },
    { q: 'How does the document-specific AI chat work?', a: 'When you select an upload, the chatbot restricts its search space specifically to that file. It runs a local semantic search to extract paragraphs matching your question and synthesizes a tutor response based strictly on that material.' },
    { q: 'Can I use it offline?', a: 'No, this production-ready deployment runs strictly on a live Express + MongoDB backend and requires a live network connection for real-time AI reasoning.' },
    { q: 'Is there a limit on file size?', a: 'Yes, files are limited to 10MB each in the free version. Premium upgrades expand this limit to 100MB per file with unlimited storage capacity.' }
  ];

  return (
    <div className="flex-1 w-full bg-[#070415] text-slate-100 flex flex-col font-sans relative">
      
      {/* Header */}
      <header className="w-full max-w-7xl mx-auto px-6 py-6 flex items-center justify-between z-10">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-lg">
            <GraduationCap size={20} className="text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight text-white font-sans">StudySync AI</span>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => triggerAuth(false)}
            className="text-sm font-semibold hover:text-cyan-400 transition-colors"
          >
            Login
          </button>
          <button 
            onClick={() => triggerAuth(true)}
            className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-indigo-500 hover:opacity-90 rounded-lg text-xs font-semibold text-white shadow-cyan-glow transition-all"
          >
            Get Started Free
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-16 pb-20 text-center flex flex-col items-center justify-center relative z-10 flex-1">
        
        {/* Sparkle Tag */}
        <div className="flex items-center space-x-2 px-3 py-1 bg-cyan-500/10 border border-cyan-400/20 text-cyan-300 rounded-full text-xs font-semibold mb-6 animate-pulse">
          <Sparkles size={14} />
          <span>Empowering university students worldwide</span>
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-6 max-w-4xl text-white">
          Study Smarter with <span className="gradient-text font-extrabold">AI-Powered</span> Academic Assistant
        </h1>
        
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mb-10 leading-relaxed font-light font-sans">
          Upload your lecture slides, textbook PDFs, or photos of handwritten notes. Get instant summaries, structured study cards, interactive quizzes, and doubt solving.
        </p>

        {/* CTA Button Group */}
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center w-full max-w-md mb-16">
          <button 
            onClick={() => triggerAuth(true)}
            className="px-8 py-4 bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:opacity-90 rounded-xl text-sm font-semibold text-white shadow-cyan-glow flex items-center justify-center space-x-2 transition-all"
          >
            <span>Get Started Now</span>
            <ArrowRight size={16} />
          </button>
        </div>

        {/* Glass Dashboard Preview */}
        <div className="w-full max-w-5xl rounded-2xl border border-white/5 bg-[#0f0b24]/40 p-4 shadow-2xl relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center space-x-2 mb-4 pb-2 border-b border-white/5 text-slate-500 text-xs">
            <span className="w-3 h-3 rounded-full bg-red-500/60"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-500/60"></span>
            <span className="w-3 h-3 rounded-full bg-green-500/60"></span>
            <span className="ml-2 font-mono select-none">studysync-assistant-dashboard.exe</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            <div className="p-5 rounded-xl bg-white/5 border border-white/5">
              <span className="text-[10px] text-cyan-400 font-bold uppercase">Topic Focus</span>
              <h3 className="text-lg font-bold mt-1 mb-2">Introduction to Neural Networks</h3>
              <p className="text-xs text-slate-400 leading-relaxed">Generated notes on layers, activation math, and SGD optimization gradients.</p>
            </div>
            <div className="p-5 rounded-xl bg-white/5 border border-white/5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-purple-400 font-bold uppercase">AI Mini-Quiz</span>
                <p className="text-sm font-semibold mt-1 mb-3">Which activation function mitigates the vanishing gradient problem?</p>
              </div>
              <div className="space-y-1">
                <span className="block text-[10px] px-2.5 py-1 bg-cyan-400/20 text-cyan-300 rounded border border-cyan-400/30">✔ ReLU (Correct)</span>
                <span className="block text-[10px] px-2.5 py-1 bg-white/5 text-slate-400 rounded">Sigmoid</span>
              </div>
            </div>
            <div className="p-5 rounded-xl bg-white/5 border border-white/5">
              <span className="text-[10px] text-pink-400 font-bold uppercase">AI Doubts Assistant</span>
              <p className="text-xs text-slate-300 italic mt-2">"Ask me about activation functions in the neural net slides..."</p>
              <div className="mt-4 p-2.5 bg-slate-950/60 rounded text-[10px] text-slate-400 leading-relaxed border border-white/5">
                Sigmoid squashes outputs between 0 and 1, mapping to binary classification probabilities.
              </div>
            </div>
          </div>
        </div>

      </section>

      {/* Features Grid */}
      <section className="bg-slate-950/30 border-y border-white/5 py-24 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">Complete AI Study Toolkit</h2>
            <p className="text-slate-400 max-w-xl mx-auto text-sm md:text-base">Everything a student needs to parse notes, compile materials, test their skills, and focus.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feat, idx) => {
              const Icon = feat.icon;
              return (
                <div key={idx} className="p-6 rounded-2xl glass-panel border border-white/5 flex flex-col items-start hover:border-cyan-400/30 transition-all">
                  <div className="p-3 bg-gradient-to-tr from-cyan-400/10 to-purple-600/10 border border-cyan-400/20 rounded-xl text-cyan-400 mb-4">
                    <Icon size={20} />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{feat.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{feat.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline How it works */}
      <section className="py-24 relative z-10">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">How StudySync AI Works</h2>
            <p className="text-slate-400 text-sm">Follow three easy steps to unlock modern learning accelerators.</p>
          </div>
          <div className="space-y-12">
            <div className="flex flex-col md:flex-row items-start md:space-x-8">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 text-cyan-400 flex items-center justify-center font-bold text-lg shrink-0 mb-4 md:mb-0">1</div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Upload Lecture Materials</h3>
                <p className="text-sm text-slate-400 leading-relaxed">Drag and drop slides, PDFs, notes, or handwritten snaps. Organize them by subject folders in your study portal.</p>
              </div>
            </div>
            <div className="flex flex-col md:flex-row items-start md:space-x-8">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-400/30 text-purple-400 flex items-center justify-center font-bold text-lg shrink-0 mb-4 md:mb-0">2</div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">AI Synthesizes Material</h3>
                <p className="text-sm text-slate-400 leading-relaxed">The integrated Gemini engine extracts content, OCRs writing, and instantly forms concise summaries, formula indexes, flashcards, quizzes, and ASCII roadmaps.</p>
              </div>
            </div>
            <div className="flex flex-col md:flex-row items-start md:space-x-8">
              <div className="w-12 h-12 rounded-2xl bg-pink-500/10 border border-pink-400/30 text-pink-400 flex items-center justify-center font-bold text-lg shrink-0 mb-4 md:mb-0">3</div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Practice and Track Stats</h3>
                <p className="text-sm text-slate-400 leading-relaxed">Review cards with flashcards tools, play MCQ quizzes, chat with your documents directly, and track daily learn goals inside the interactive dashboard.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Options */}
      <section className="bg-slate-950/20 border-t border-white/5 py-24 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">Sleek, Transparent Plans</h2>
            <p className="text-slate-400 text-sm">Start for free and upgrade as your study needs grow.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {/* Free tier */}
            <div className="p-8 rounded-2xl bg-white/5 border border-white/5 relative flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">Standard</span>
                <h3 className="text-2xl font-bold text-white mt-1 mb-4">Free Tier</h3>
                <p className="text-3xl font-extrabold text-white mb-6">$0 <span className="text-sm font-normal text-slate-500">/ forever</span></p>
                <ul className="space-y-3 mb-8 text-xs text-slate-400">
                  <li className="flex items-center space-x-2"><Check size={14} className="text-cyan-400" /><span>Up to 10 uploads (10MB limit)</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-cyan-400" /><span>General note generator (modes enabled)</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-cyan-400" /><span>Daily streak tracker & Pomodoro clock</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-cyan-400" /><span>Real-time database storage</span></li>
                </ul>
              </div>
              <button 
                onClick={() => triggerAuth(true)}
                className="w-full py-3 bg-white/10 hover:bg-white/15 text-white font-semibold text-xs rounded-xl transition-all"
              >
                Sign Up Free
              </button>
            </div>
            
            {/* Pro tier */}
            <div className="p-8 rounded-2xl bg-gradient-to-b from-purple-950/40 to-slate-950 border border-purple-500/30 relative flex flex-col justify-between shadow-purple-glow">
              <div className="absolute top-4 right-4 px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded border border-purple-500/40 text-[10px] font-bold uppercase tracking-widest">Recommended</div>
              <div>
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider">Premium Access</span>
                <h3 className="text-2xl font-bold text-white mt-1 mb-4">Academic Pro</h3>
                <p className="text-3xl font-extrabold text-white mb-6">$4.99 <span className="text-sm font-normal text-slate-500">/ month</span></p>
                <ul className="space-y-3 mb-8 text-xs text-slate-400">
                  <li className="flex items-center space-x-2"><Check size={14} className="text-purple-400" /><span>Unlimited uploads (100MB limit)</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-purple-400" /><span>Full OCR handwriting conversion models</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-purple-400" /><span>Priority Gemini-2.5 API token credits</span></li>
                  <li className="flex items-center space-x-2"><Check size={14} className="text-purple-400" /><span>Sync planner reminders with calendar APIs</span></li>
                </ul>
              </div>
              <button 
                onClick={() => triggerAuth(true)}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 hover:opacity-90 text-white font-semibold text-xs rounded-xl shadow-cyan-glow transition-all"
              >
                Unlock Pro Account
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs Panel */}
      <section className="py-24 relative z-10 max-w-4xl mx-auto px-6 text-left">
        <h2 className="text-3xl md:text-5xl font-extrabold text-center text-white mb-16">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = activeFaq === idx;
            return (
              <div key={idx} className="rounded-xl border border-white/5 bg-[#0f0b24]/20 overflow-hidden transition-all duration-150">
                <button
                  onClick={() => setActiveFaq(isOpen ? null : idx)}
                  className="w-full p-5 flex items-center justify-between text-slate-200 hover:text-white font-bold text-sm"
                >
                  <span>{faq.q}</span>
                  <ChevronDown size={18} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''} text-slate-400`} />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-white/5 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5 text-center text-xs text-slate-500 relative z-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <GraduationCap size={16} className="text-cyan-400" />
            <span className="font-semibold text-slate-400">StudySync AI academic Assistant Portal</span>
          </div>
          <p>© 2026 StudySync Platform. All Rights Secured.</p>
        </div>
      </footer>

    </div>
  );
}
