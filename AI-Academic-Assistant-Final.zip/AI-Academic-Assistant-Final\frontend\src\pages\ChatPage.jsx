import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { 
  Send, 
  Sparkles, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Bot, 
  User, 
  ChevronDown, 
  FileText,
  HelpCircle,
  Copy
} from 'lucide-react';

const SUGGESTIONS = [
  "Summarize this study material.",
  "Give important exam questions.",
  "Explain the main formula/equations.",
  "Provide a brief list of key formulas.",
  "Explain quantum tunneling simply."
];

// Helper to render LaTeX using KaTeX loaded globally in window
const MathRenderer = ({ math, block = false }) => {
  const containerRef = useRef(null);

  useEffect(() => {
    if (containerRef.current && window.katex) {
      try {
        window.katex.render(math, containerRef.current, {
          displayMode: block,
          throwOnError: false
        });
      } catch (err) {
        console.error('KaTeX error:', err);
        containerRef.current.textContent = math;
      }
    } else if (containerRef.current) {
      containerRef.current.textContent = math;
    }
  }, [math, block]);

  return <span ref={containerRef} className={block ? "block text-center my-2" : "inline-block px-0.5"} />;
};

// Custom Markdown + LaTeX segment parser and renderer
const RichMessageText = ({ text }) => {
  if (!text) return null;

  // Regex to split by code blocks (```), block math ($$), and inline math ($)
  const regex = /(\`\`\`[\s\S]*?\`\`\`|\$\$[\s\S]*?\$\$|\$.*?\$)/g;
  const segments = text.split(regex);

  const renderNormalMarkdown = (txt) => {
    let html = txt
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Parse Tables
    const lines = html.split('\n');
    let inTable = false;
    let tableHtml = '';
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith('|') && line.endsWith('|')) {
        if (!inTable) {
          inTable = true;
          tableHtml = '<div class="overflow-x-auto my-3"><table class="min-w-full border border-white/10 text-left text-xs bg-slate-950/40 rounded-lg">';
        }
        
        const cells = line.split('|').map(c => c.trim()).slice(1, -1);
        const isSeparator = cells.every(c => /^:-*:$/.test(c) || /^-+$/.test(c));
        if (isSeparator) continue;
        
        tableHtml += '<tr class="border-b border-white/5">';
        cells.forEach(cell => {
          const isHeader = i === 0 || (i > 0 && !lines[i-1].trim().startsWith('|'));
          if (isHeader) {
            tableHtml += `<th class="px-3 py-1.5 bg-white/5 font-bold border-r border-white/10 text-slate-100">${cell}</th>`;
          } else {
            tableHtml += `<td class="px-3 py-1.5 border-r border-white/10 text-slate-350">${cell}</td>`;
          }
        });
        tableHtml += '</tr>';
      } else {
        if (inTable) {
          inTable = false;
          tableHtml += '</table></div>';
          lines[i] = tableHtml + '\n' + lines[i];
          tableHtml = '';
        }
      }
    }
    if (inTable) {
      tableHtml += '</table></div>';
      html = lines.join('\n') + tableHtml;
    } else {
      html = lines.join('\n');
    }

    // Headings
    html = html.replace(/^#### (.*?)$/gm, '<h4 class="text-xs font-bold text-white mt-3 mb-1">$1</h4>');
    html = html.replace(/^### (.*?)$/gm, '<h3 class="text-sm font-bold text-white mt-4 mb-2">$1</h3>');
    html = html.replace(/^## (.*?)$/gm, '<h2 class="text-base font-bold text-white mt-5 mb-3 border-b border-white/5 pb-1">$1</h2>');
    html = html.replace(/^# (.*?)$/gm, '<h1 class="text-lg font-bold text-white mt-6 mb-4 border-b border-white/10 pb-1.5">$1</h1>');

    // Bullet Lists
    html = html.replace(/^\s*[-*]\s+(.*?)$/gm, '<li class="list-disc list-inside ml-4 my-1 text-slate-355">$1</li>');
    
    // Numbered Lists
    html = html.replace(/^\s*\d+\.\s+(.*?)$/gm, '<li class="list-decimal list-inside ml-4 my-1 text-slate-355">$1</li>');

    // Bold
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-white">$1</strong>');
    
    // Italics
    html = html.replace(/\*(.*?)\*/g, '<em class="italic text-slate-300">$1</em>');

    // Inline Code
    html = html.replace(/`(.*?)`/g, '<code class="px-1.5 py-0.5 bg-slate-950 border border-white/5 rounded text-cyan-300 font-mono text-[11px]">$1</code>');

    // Line breaks
    html = html.replace(/\n/g, '<br />');

    return <div dangerouslySetInnerHTML={{ __html: html }} className="space-y-1.5" />;
  };

  const handleCopyCode = (codeText) => {
    navigator.clipboard.writeText(codeText);
    alert('Code block copied!');
  };

  return (
    <div className="space-y-2 text-slate-200">
      {segments.map((segment, index) => {
        if (segment.startsWith('```') && segment.endsWith('```')) {
          const match = segment.match(/^```(\w*)\n([\s\S]*)\n```$/);
          const lang = match ? match[1] : '';
          const code = match ? match[2] : segment.slice(3, -3);
          
          return (
            <div key={index} className="my-3 rounded-xl overflow-hidden border border-white/5 bg-slate-950 shadow-md">
              <div className="flex justify-between items-center px-4 py-2 bg-white/5 text-[10px] text-slate-400 border-b border-white/5 font-mono">
                <span>{lang || 'code'}</span>
                <button 
                  type="button" 
                  onClick={() => handleCopyCode(code)}
                  className="text-cyan-400 hover:text-cyan-300 transition-colors font-semibold uppercase tracking-wider"
                >
                  Copy
                </button>
              </div>
              <pre className="p-4 font-mono text-[11px] overflow-x-auto text-cyan-300 leading-normal">
                <code>{code}</code>
              </pre>
            </div>
          );
        } else if (segment.startsWith('$$') && segment.endsWith('$$')) {
          const math = segment.slice(2, -2);
          return (
            <div key={index} className="my-4 p-3 bg-slate-950/40 rounded-xl border border-white/5 flex justify-center overflow-x-auto text-white shadow-inner">
              <MathRenderer math={math} block={true} />
            </div>
          );
        } else if (segment.startsWith('$') && segment.endsWith('$')) {
          const math = segment.slice(1, -1);
          return <MathRenderer key={index} math={math} block={false} />;
        } else {
          return <React.Fragment key={index}>{renderNormalMarkdown(segment)}</React.Fragment>;
        }
      })}
    </div>
  );
};

export default function ChatPage() {
  const { 
    uploads, 
    activeUpload, 
    setActiveUpload, 
    chatHistory, 
    sendMessage, 
    loadChatHistory 
  } = useApp();

  const [input, setInput] = useState('');
  const [speechSynthesisActive, setSpeechSynthesisActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  
  const chatEndRef = useRef(null);
  const recognitionRef = useRef(null);

  // Initialize Speech Recognition API
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListening(true);
      };

      rec.onresult = (e) => {
        const transcript = e.results[0][0].transcript;
        setInput(prev => prev + ' ' + transcript);
      };

      rec.onerror = (e) => {
        console.error('Speech recognition error:', e);
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  // Sync scroll on new messages
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // Load chat logs on document switch
  useEffect(() => {
    loadChatHistory(activeUpload?._id || '');
  }, [activeUpload]);

  // Trigger TTS voice read-out on last AI message
  useEffect(() => {
    if (speechSynthesisActive && chatHistory.length > 0) {
      const lastMsg = chatHistory[chatHistory.length - 1];
      if (lastMsg.sender === 'ai') {
        speakText(lastMsg.text);
      }
    }
  }, [chatHistory, speechSynthesisActive]);

  const speakText = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // stop current speak
      // Strip markdown characters for cleaner speaking
      const cleanText = text.replace(/[*#$`_]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText.substring(0, 300));
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleSpeechRecognition = () => {
    if (!recognitionRef.current) {
      alert('Voice dictation is not fully supported in this browser. Try Google Chrome.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || chatLoading) return;

    const query = input.trim();
    setInput('');
    setChatLoading(true);
    await sendMessage(activeUpload?._id || null, query);
    setChatLoading(false);
  };

  const handleSelectSuggestion = async (suggestion) => {
    if (chatLoading) return;
    setChatLoading(true);
    await sendMessage(activeUpload?._id || null, suggestion);
    setChatLoading(false);
  };

  const handleCopyResponse = (responseText) => {
    navigator.clipboard.writeText(responseText);
    alert('AI response copied to clipboard!');
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-65px)] md:h-screen relative overflow-hidden bg-slate-50 dark:bg-[#070415] text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Top Selector Ribbon */}
      <header className="p-4 glass-panel border-b border-white/5 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-3 overflow-hidden">
          <div className="p-2 bg-purple-500/10 text-purple-400 rounded-lg">
            <Bot size={16} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase">Study Context</span>
            <div className="flex items-center space-x-2 cursor-pointer mt-0.5">
              <select 
                value={activeUpload?._id || ''} 
                onChange={(e) => {
                  const selected = uploads.find(up => up._id === e.target.value);
                  setActiveUpload(selected || null);
                }}
                className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-100 border-none outline-none focus:ring-0 focus:outline-none max-w-[200px] truncate"
              >
                <option value="" className="bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-400">General AI Assistant</option>
                {uploads.map(up => (
                  <option key={up._id} value={up._id} className="bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-100">{up.filename}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Audio controls toggler */}
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => {
              if (speechSynthesisActive) {
                window.speechSynthesis.cancel();
              }
              setSpeechSynthesisActive(!speechSynthesisActive);
            }}
            className={`p-2.5 rounded-lg border transition-all ${speechSynthesisActive ? 'bg-cyan-500/10 border-cyan-400/30 text-cyan-400 shadow-cyan-glow' : 'bg-white/5 border-white/5 text-slate-400 hover:text-slate-200'}`}
            title="Read AI replies aloud (TTS)"
          >
            {speechSynthesisActive ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
        </div>
      </header>

      {/* Conversations Board */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {chatHistory.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center max-w-md mx-auto text-center space-y-6">
            <div className="w-16 h-16 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-cyan-glow text-white animate-float">
              <Bot size={32} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800 dark:text-white font-sans">Ask your Study Material anything</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                {activeUpload 
                  ? `AI is currently reading "${activeUpload.filename}". Ask specific questions about equations, slides, or chapters inside.` 
                  : "Welcome! Select an uploaded slide deck/PDF from the dropdown above to constrain the answers to your syllabus, or ask general queries."
                }
              </p>
            </div>

            {/* Smart Suggestions Chips */}
            <div className="flex flex-wrap gap-2 justify-center pt-4">
              {SUGGESTIONS.map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectSuggestion(sug)}
                  className="px-3.5 py-2 bg-white/5 border border-slate-200/50 dark:border-white/5 hover:border-cyan-400/20 text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-white rounded-full text-[10px] font-semibold transition-all"
                >
                  {sug}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto space-y-5 pb-4">
            {chatHistory.map((chat) => {
              const isAi = chat.sender === 'ai';
              return (
                <div key={chat._id} className={`flex space-x-3 ${isAi ? 'justify-start' : 'justify-end'}`}>
                  {isAi && (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-cyan-glow">
                      <Bot size={14} />
                    </div>
                  )}
                  <div className={`
                    p-4 rounded-2xl max-w-[85%] text-xs leading-relaxed transition-all shadow-md
                    ${isAi 
                      ? 'glass-panel text-slate-800 dark:text-slate-200 border border-slate-200/60 dark:border-white/5 bg-white/60 dark:bg-white/5' 
                      : 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-cyan-glow font-medium'
                    }
                  `}>
                    {/* Render Rich Message Text */}
                    {isAi ? (
                      <RichMessageText text={chat.text} />
                    ) : (
                      <div className="whitespace-pre-line">{chat.text}</div>
                    )}
                    
                    {isAi && (
                      <div className="mt-3 pt-2.5 border-t border-slate-200/40 dark:border-white/5 flex items-center space-x-3 text-[9px] font-bold uppercase tracking-wider text-cyan-500 dark:text-cyan-400">
                        <button 
                          onClick={() => speakText(chat.text)}
                          className="hover:underline flex items-center gap-1"
                        >
                          <Volume2 size={10} /> Speak
                        </button>
                        <span className="text-slate-300 dark:text-white/10">|</span>
                        <button 
                          onClick={() => handleCopyResponse(chat.text)}
                          className="hover:underline flex items-center gap-1"
                        >
                          <Copy size={10} /> Copy
                        </button>
                      </div>
                    )}
                  </div>
                  {!isAi && (
                    <div className="w-8 h-8 rounded-full bg-slate-200/80 dark:bg-white/10 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
                      <User size={14} />
                    </div>
                  )}
                </div>
              );
            })}
            
            {chatLoading && (
              <div className="flex space-x-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-cyan-glow">
                  <Bot size={14} />
                </div>
                <div className="p-4 rounded-2xl glass-panel text-slate-500 border border-slate-200/50 dark:border-white/5 flex items-center space-x-1.5">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>
        )}
      </div>

      {/* Message Input Bar */}
      <footer className="p-4 bg-white/40 dark:bg-slate-950/20 border-t border-slate-200/60 dark:border-white/5 shrink-0">
        <form onSubmit={handleSend} className="max-w-3xl mx-auto flex items-center space-x-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 p-2 rounded-xl focus-within:border-cyan-400 focus-within:box-shadow-cyan-glow transition-all shadow-sm">
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            className={`p-2.5 rounded-lg transition-all ${isListening ? 'bg-red-500/20 text-red-400 animate-pulse' : 'text-slate-400 hover:text-slate-200'}`}
            title="Speech to Text"
          >
            {isListening ? <MicOff size={18} /> : <Mic size={18} />}
          </button>
          
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? "Listening to voice dictation..." : "Ask your AI Study Buddy..."}
            className="flex-1 bg-transparent border-none outline-none text-xs text-slate-800 dark:text-slate-100 placeholder-slate-500 focus:ring-0 focus:outline-none py-2"
          />

          <button
            type="submit"
            className="p-2.5 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white shadow-cyan-glow hover:opacity-90 transition-opacity"
          >
            <Send size={14} />
          </button>
        </form>
      </footer>

    </div>
  );
}
